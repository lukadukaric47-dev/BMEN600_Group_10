from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

from sklearn.model_selection import StratifiedKFold

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
)


# ============================================================
# 1. DATASET ROOT
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)


# ============================================================
# 2. INPUT FILE
# ============================================================

input_file = (
    dataset_root
    / "slice_level_ct_features.csv"
)


# ============================================================
# 3. OUTPUT FILES
# ============================================================

prediction_file = (
    dataset_root
    / "rf_patient_nested_predictions.csv"
)

fold_summary_file = (
    dataset_root
    / "rf_patient_nested_fold_summary.csv"
)


# ============================================================
# 4. LOAD DATA
# ============================================================

if not input_file.exists():

    raise FileNotFoundError(
        f"Could not find:\n{input_file}"
    )


df = pd.read_csv(
    input_file
)


print()
print("========================================")
print("DATASET")
print("========================================")

print(
    f"Total usable slices: "
    f"{len(df)}"
)

print(
    f"Patients: "
    f"{df['Patient_ID'].nunique()}"
)

print()


# ============================================================
# 5. CT FEATURES
# ============================================================

features = [

    "Mean_HU",
    "Median_HU",
    "Std_HU",

    "Min_HU",
    "Max_HU",

    "P10_HU",
    "P25_HU",
    "P75_HU",
    "P90_HU",
    "P95_HU",
    "P99_HU",

    "IQR_HU",

    "Fraction_Above_40HU",
    "Fraction_Above_50HU",
    "Fraction_Above_60HU",
    "Fraction_Above_70HU",
    "Fraction_Above_80HU",

    "HU_Skewness",
    "HU_Kurtosis",
    "HU_Entropy",

    "Top1Percent_Mean_HU",
    "Top5Percent_Mean_HU",

    "Largest_Above50HU_Area_mm2",
    "Largest_Above60HU_Area_mm2",
    "Largest_Above70HU_Area_mm2",
]


# ============================================================
# 6. CHECK FEATURES
# ============================================================

missing_features = [

    feature

    for feature in features

    if feature not in df.columns
]


if len(missing_features) > 0:

    print("Missing features:")

    for feature in missing_features:

        print(feature)

    raise ValueError(
        "Required features are missing."
    )


# ============================================================
# 7. CREATE PATIENT-LEVEL TABLE
# ============================================================

patient_table = (

    df.groupby(
        "Patient_ID",
        as_index=False,
    )

    .agg(
        Patient_ICH=(
            "Patient_ICH",
            "max",
        ),

        Number_of_Slices=(
            "Patient_ID",
            "size",
        ),
    )
)


patient_table[
    "Patient_ID"
] = (
    patient_table[
        "Patient_ID"
    ]
    .astype(int)
)


patient_table[
    "Patient_ICH"
] = (
    patient_table[
        "Patient_ICH"
    ]
    .astype(int)
)


print(
    "========================================"
)

print(
    "PATIENT CLASS DISTRIBUTION"
)

print(
    "========================================"
)


print(
    patient_table[
        "Patient_ICH"
    ].value_counts(
        sort=False
    )
)

print()


# ============================================================
# 8. MODEL
# ============================================================

def create_model():

    return Pipeline(
        steps=[

            (
                "imputer",

                SimpleImputer(
                    strategy="median"
                ),
            ),

            (
                "rf",

                RandomForestClassifier(

                    n_estimators=500,

                    random_state=42,

                    n_jobs=-1,

                    class_weight="balanced_subsample",

                    max_features="sqrt",

                    min_samples_leaf=2,
                ),
            ),
        ]
    )


# ============================================================
# 9. PATIENT AGGREGATION FUNCTIONS
# ============================================================

def calculate_patient_score(
    probabilities,
    method,
):

    probabilities = np.asarray(
        probabilities,
        dtype=float,
    )


    if len(probabilities) == 0:

        return np.nan


    sorted_probabilities = np.sort(
        probabilities
    )[::-1]


    if method == "MAX":

        return float(
            np.max(
                probabilities
            )
        )


    elif method == "TOP3_MEAN":

        n = min(
            3,
            len(
                sorted_probabilities
            ),
        )

        return float(
            np.mean(
                sorted_probabilities[
                    :n
                ]
            )
        )


    elif method == "TOP5_MEAN":

        n = min(
            5,
            len(
                sorted_probabilities
            ),
        )

        return float(
            np.mean(
                sorted_probabilities[
                    :n
                ]
            )
        )


    elif method == "P95":

        return float(
            np.percentile(
                probabilities,
                95,
            )
        )


    else:

        raise ValueError(
            f"Unknown aggregation method: "
            f"{method}"
        )


# ============================================================
# 10. CREATE PATIENT SCORES FROM SLICE PREDICTIONS
# ============================================================

def aggregate_predictions(
    slice_prediction_table,
    patient_truth_table,
):

    rows = []


    for patient_id, patient_data in (
        slice_prediction_table.groupby(
            "Patient_ID"
        )
    ):


        probabilities = (
            patient_data[
                "Probability"
            ]
            .values
        )


        true_patient_ich = int(

            patient_truth_table.loc[
                patient_truth_table[
                    "Patient_ID"
                ]
                ==
                patient_id,

                "Patient_ICH",
            ].iloc[0]
        )


        rows.append(
            {
                "Patient_ID":
                    int(
                        patient_id
                    ),

                "True_ICH":
                    true_patient_ich,

                "MAX":
                    calculate_patient_score(
                        probabilities,
                        "MAX",
                    ),

                "TOP3_MEAN":
                    calculate_patient_score(
                        probabilities,
                        "TOP3_MEAN",
                    ),

                "TOP5_MEAN":
                    calculate_patient_score(
                        probabilities,
                        "TOP5_MEAN",
                    ),

                "P95":
                    calculate_patient_score(
                        probabilities,
                        "P95",
                    ),

                "Number_of_Slices":
                    len(
                        probabilities
                    ),
            }
        )


    return pd.DataFrame(
        rows
    )


# ============================================================
# 11. FIND BEST PATIENT AGGREGATION + THRESHOLD
# ============================================================

def select_best_patient_rule(
    patient_scores,
):

    candidate_methods = [

        "MAX",
        "TOP3_MEAN",
        "TOP5_MEAN",
        "P95",
    ]


    thresholds = np.arange(
        0.05,
        0.91,
        0.01,
    )


    best_result = None


    for method in candidate_methods:

        scores = (
            patient_scores[
                method
            ]
            .values
        )

        true_values = (
            patient_scores[
                "True_ICH"
            ]
            .values
        )


        for threshold in thresholds:

            predictions = (
                scores
                >=
                threshold
            ).astype(int)


            cm = confusion_matrix(
                true_values,
                predictions,
                labels=[0, 1],
            )


            tn, fp, fn, tp = (
                cm.ravel()
            )


            sensitivity = (

                tp
                /
                (
                    tp + fn
                )

                if (
                    tp + fn
                ) > 0

                else 0
            )


            specificity = (

                tn
                /
                (
                    tn + fp
                )

                if (
                    tn + fp
                ) > 0

                else 0
            )


            balanced_accuracy = (
                sensitivity
                +
                specificity
            ) / 2


            current_result = {

                "Method":
                    method,

                "Threshold":
                    float(
                        threshold
                    ),

                "Balanced_Accuracy":
                    balanced_accuracy,

                "Sensitivity":
                    sensitivity,

                "Specificity":
                    specificity,
            }


            # -----------------------------------------------
            # Primary criterion:
            # highest balanced accuracy
            #
            # Tie-break:
            # higher sensitivity
            # -----------------------------------------------

            if best_result is None:

                best_result = (
                    current_result
                )


            elif (
                current_result[
                    "Balanced_Accuracy"
                ]
                >
                best_result[
                    "Balanced_Accuracy"
                ]
            ):

                best_result = (
                    current_result
                )


            elif np.isclose(
                current_result[
                    "Balanced_Accuracy"
                ],
                best_result[
                    "Balanced_Accuracy"
                ],
            ):

                if (
                    current_result[
                        "Sensitivity"
                    ]
                    >
                    best_result[
                        "Sensitivity"
                    ]
                ):

                    best_result = (
                        current_result
                    )


    return best_result


# ============================================================
# 12. OUTER PATIENT-LEVEL CROSS-VALIDATION
# ============================================================

outer_cv = StratifiedKFold(

    n_splits=5,

    shuffle=True,

    random_state=42,
)


# ============================================================
# 13. STORAGE
# ============================================================

all_outer_patient_results = []

fold_summaries = []


# ============================================================
# 14. OUTER CV
# ============================================================

for outer_fold, (
    outer_train_patient_index,
    outer_test_patient_index,
) in enumerate(

    outer_cv.split(

        patient_table[
            "Patient_ID"
        ],

        patient_table[
            "Patient_ICH"
        ],
    ),

    start=1,
):


    print()
    print(
        "========================================"
    )

    print(
        f"OUTER FOLD {outer_fold}"
    )

    print(
        "========================================"
    )


    outer_train_patients = (

        patient_table.iloc[
            outer_train_patient_index
        ]
        .reset_index(
            drop=True
        )
    )


    outer_test_patients = (

        patient_table.iloc[
            outer_test_patient_index
        ]
        .reset_index(
            drop=True
        )
    )


    outer_train_ids = set(

        outer_train_patients[
            "Patient_ID"
        ]
        .tolist()
    )


    outer_test_ids = set(

        outer_test_patients[
            "Patient_ID"
        ]
        .tolist()
    )


    overlap = (
        outer_train_ids
        .intersection(
            outer_test_ids
        )
    )


    print(
        f"Training patients: "
        f"{len(outer_train_ids)}"
    )

    print(
        f"Testing patients: "
        f"{len(outer_test_ids)}"
    )

    print(
        f"Patient overlap: "
        f"{len(overlap)}"
    )


    if len(overlap) > 0:

        raise RuntimeError(
            "Patient leakage detected."
        )


    # ========================================================
    # 15. INNER PATIENT CV
    # ========================================================

    inner_cv = StratifiedKFold(

        n_splits=4,

        shuffle=True,

        random_state=(
            100
            +
            outer_fold
        ),
    )


    inner_slice_predictions = []


    for (
        inner_train_patient_index,
        inner_valid_patient_index,
    ) in inner_cv.split(

        outer_train_patients[
            "Patient_ID"
        ],

        outer_train_patients[
            "Patient_ICH"
        ],
    ):


        inner_train_patients = (

            outer_train_patients.iloc[
                inner_train_patient_index
            ]
        )


        inner_valid_patients = (

            outer_train_patients.iloc[
                inner_valid_patient_index
            ]
        )


        inner_train_ids = (

            inner_train_patients[
                "Patient_ID"
            ]
            .tolist()
        )


        inner_valid_ids = (

            inner_valid_patients[
                "Patient_ID"
            ]
            .tolist()
        )


        # ====================================================
        # 16. GET SLICE DATA
        # ====================================================

        inner_train_slices = df[
            df[
                "Patient_ID"
            ].isin(
                inner_train_ids
            )
        ]


        inner_valid_slices = df[
            df[
                "Patient_ID"
            ].isin(
                inner_valid_ids
            )
        ]


        X_inner_train = (
            inner_train_slices[
                features
            ]
        )


        y_inner_train = (
            inner_train_slices[
                "Slice_ICH"
            ]
            .astype(int)
        )


        X_inner_valid = (
            inner_valid_slices[
                features
            ]
        )


        # ====================================================
        # 17. TRAIN INNER SLICE RF
        # ====================================================

        inner_model = create_model()


        inner_model.fit(
            X_inner_train,
            y_inner_train,
        )


        # ====================================================
        # 18. PREDICT VALIDATION PATIENT SLICES
        # ====================================================

        probabilities = (

            inner_model
            .predict_proba(
                X_inner_valid
            )[
                :,
                1
            ]
        )


        inner_prediction_table = pd.DataFrame(
            {
                "Patient_ID":

                    inner_valid_slices[
                        "Patient_ID"
                    ].values,

                "Probability":

                    probabilities,
            }
        )


        inner_slice_predictions.append(
            inner_prediction_table
        )


    # ========================================================
    # 19. COMBINE ALL INNER OOF SLICE PREDICTIONS
    # ========================================================

    inner_slice_predictions = pd.concat(
        inner_slice_predictions,
        ignore_index=True,
    )


    # Every outer-training patient should
    # now have unseen inner predictions.

    predicted_inner_patients = set(

        inner_slice_predictions[
            "Patient_ID"
        ]
        .unique()
    )


    if predicted_inner_patients != outer_train_ids:

        raise RuntimeError(
            "Inner CV did not generate predictions "
            "for every outer-training patient."
        )


    # ========================================================
    # 20. AGGREGATE INNER SLICE PROBABILITIES
    # ========================================================

    inner_patient_scores = (
        aggregate_predictions(

            inner_slice_predictions,

            outer_train_patients,
        )
    )


    # ========================================================
    # 21. SELECT BEST AGGREGATION RULE
    # ========================================================

    best_rule = (
        select_best_patient_rule(
            inner_patient_scores
        )
    )


    selected_method = (
        best_rule[
            "Method"
        ]
    )


    selected_threshold = (
        best_rule[
            "Threshold"
        ]
    )


    print()

    print(
        f"Selected aggregation method: "
        f"{selected_method}"
    )

    print(
        f"Selected patient threshold: "
        f"{selected_threshold:.2f}"
    )

    print(
        f"Inner balanced accuracy: "
        f"{best_rule['Balanced_Accuracy']:.3f}"
    )

    print(
        f"Inner sensitivity: "
        f"{best_rule['Sensitivity']:.3f}"
    )

    print(
        f"Inner specificity: "
        f"{best_rule['Specificity']:.3f}"
    )


    # ========================================================
    # 22. TRAIN FINAL SLICE RF
    #     USING ALL OUTER-TRAIN PATIENTS
    # ========================================================

    outer_train_slices = df[
        df[
            "Patient_ID"
        ].isin(
            outer_train_ids
        )
    ]


    outer_test_slices = df[
        df[
            "Patient_ID"
        ].isin(
            outer_test_ids
        )
    ]


    X_outer_train = (
        outer_train_slices[
            features
        ]
    )


    y_outer_train = (
        outer_train_slices[
            "Slice_ICH"
        ]
        .astype(int)
    )


    X_outer_test = (
        outer_test_slices[
            features
        ]
    )


    final_slice_model = (
        create_model()
    )


    final_slice_model.fit(
        X_outer_train,
        y_outer_train,
    )


    # ========================================================
    # 23. PREDICT COMPLETELY UNSEEN PATIENTS
    # ========================================================

    outer_test_probability = (

        final_slice_model
        .predict_proba(
            X_outer_test
        )[
            :,
            1
        ]
    )


    outer_test_slice_predictions = (
        pd.DataFrame(
            {
                "Patient_ID":

                    outer_test_slices[
                        "Patient_ID"
                    ].values,

                "Probability":

                    outer_test_probability,
            }
        )
    )


    # ========================================================
    # 24. AGGREGATE OUTER TEST PATIENTS
    # ========================================================

    outer_patient_scores = (
        aggregate_predictions(

            outer_test_slice_predictions,

            outer_test_patients,
        )
    )


    outer_patient_scores[
        "Selected_Score"
    ] = (
        outer_patient_scores[
            selected_method
        ]
    )


    outer_patient_scores[
        "Prediction"
    ] = (

        outer_patient_scores[
            "Selected_Score"
        ]
        >=
        selected_threshold

    ).astype(int)


    outer_patient_scores[
        "Outer_Fold"
    ] = (
        outer_fold
    )


    outer_patient_scores[
        "Selected_Method"
    ] = (
        selected_method
    )


    outer_patient_scores[
        "Selected_Threshold"
    ] = (
        selected_threshold
    )


    all_outer_patient_results.append(
        outer_patient_scores
    )


    # ========================================================
    # 25. OUTER FOLD METRICS
    # ========================================================

    true_outer = (
        outer_patient_scores[
            "True_ICH"
        ]
        .astype(int)
    )


    predicted_outer = (
        outer_patient_scores[
            "Prediction"
        ]
        .astype(int)
    )


    score_outer = (
        outer_patient_scores[
            "Selected_Score"
        ]
        .astype(float)
    )


    cm = confusion_matrix(
        true_outer,
        predicted_outer,
        labels=[0, 1],
    )


    tn, fp, fn, tp = (
        cm.ravel()
    )


    sensitivity = (

        tp
        /
        (tp + fn)

        if (
            tp + fn
        ) > 0

        else 0
    )


    specificity = (

        tn
        /
        (tn + fp)

        if (
            tn + fp
        ) > 0

        else 0
    )


    balanced_accuracy = (
        sensitivity
        +
        specificity
    ) / 2


    if len(
        np.unique(
            true_outer
        )
    ) == 2:

        auc = roc_auc_score(
            true_outer,
            score_outer,
        )

    else:

        auc = np.nan


    print()

    print(
        f"OUTER sensitivity: "
        f"{sensitivity:.3f}"
    )

    print(
        f"OUTER specificity: "
        f"{specificity:.3f}"
    )

    print(
        f"OUTER balanced accuracy: "
        f"{balanced_accuracy:.3f}"
    )

    print(
        f"OUTER ROC-AUC: "
        f"{auc:.3f}"
    )


    print()

    print(
        "Outer confusion matrix:"
    )

    print(
        cm
    )


    fold_summaries.append(
        {
            "Outer_Fold":
                outer_fold,

            "Selected_Method":
                selected_method,

            "Selected_Threshold":
                selected_threshold,

            "Inner_Balanced_Accuracy":
                best_rule[
                    "Balanced_Accuracy"
                ],

            "Inner_Sensitivity":
                best_rule[
                    "Sensitivity"
                ],

            "Inner_Specificity":
                best_rule[
                    "Specificity"
                ],

            "Outer_Sensitivity":
                sensitivity,

            "Outer_Specificity":
                specificity,

            "Outer_Balanced_Accuracy":
                balanced_accuracy,

            "Outer_ROC_AUC":
                auc,
        }
    )


# ============================================================
# 26. COMBINE ALL OUTER TEST PATIENTS
# ============================================================

final_predictions = pd.concat(
    all_outer_patient_results,
    ignore_index=True,
)


final_predictions = (
    final_predictions
    .sort_values(
        "Patient_ID"
    )
    .reset_index(
        drop=True
    )
)


# ============================================================
# 27. CHECK ALL 50 PATIENTS HAVE ONE PREDICTION
# ============================================================

if len(
    final_predictions
) != len(
    patient_table
):

    raise RuntimeError(
        "Not every patient received exactly "
        "one outer-fold prediction."
    )


if (
    final_predictions[
        "Patient_ID"
    ].nunique()
    !=
    len(
        patient_table
    )
):

    raise RuntimeError(
        "Duplicate or missing patient predictions."
    )


# ============================================================
# 28. FINAL PATIENT-LEVEL RESULTS
# ============================================================

true_final = (
    final_predictions[
        "True_ICH"
    ]
    .astype(int)
)


predicted_final = (
    final_predictions[
        "Prediction"
    ]
    .astype(int)
)


score_final = (
    final_predictions[
        "Selected_Score"
    ]
    .astype(float)
)


cm_final = confusion_matrix(
    true_final,
    predicted_final,
    labels=[0, 1],
)


tn, fp, fn, tp = (
    cm_final.ravel()
)


accuracy = accuracy_score(
    true_final,
    predicted_final,
)


balanced_accuracy = (
    balanced_accuracy_score(
        true_final,
        predicted_final,
    )
)


sensitivity = recall_score(
    true_final,
    predicted_final,
    zero_division=0,
)


specificity = (

    tn
    /
    (
        tn + fp
    )
)


precision = precision_score(
    true_final,
    predicted_final,
    zero_division=0,
)


f1 = f1_score(
    true_final,
    predicted_final,
    zero_division=0,
)


# NOTE:
# Selected patient scoring method can differ between folds.
# Therefore this overall AUC is useful but should be
# interpreted more cautiously than the classification metrics.

roc_auc = roc_auc_score(
    true_final,
    score_final,
)


average_precision = (
    average_precision_score(
        true_final,
        score_final,
    )
)


print()
print(
    "========================================"
)

print(
    "FINAL PATIENT-LEVEL RESULTS"
)

print(
    "========================================"
)


print(
    f"Accuracy: "
    f"{accuracy:.3f}"
)

print(
    f"Balanced accuracy: "
    f"{balanced_accuracy:.3f}"
)

print(
    f"Sensitivity: "
    f"{sensitivity:.3f}"
)

print(
    f"Specificity: "
    f"{specificity:.3f}"
)

print(
    f"Precision: "
    f"{precision:.3f}"
)

print(
    f"F1 score: "
    f"{f1:.3f}"
)

print(
    f"ROC-AUC: "
    f"{roc_auc:.3f}"
)

print(
    f"Average precision: "
    f"{average_precision:.3f}"
)


print()

print(
    "Confusion Matrix:"
)

print(
    cm_final
)


# ============================================================
# 29. FOLD SUMMARY
# ============================================================

fold_summary = pd.DataFrame(
    fold_summaries
)


print()
print(
    "========================================"
)

print(
    "AGGREGATION RULES BY FOLD"
)

print(
    "========================================"
)


print(
    fold_summary.to_string(
        index=False
    )
)


# ============================================================
# 30. AGGREGATION METHOD FREQUENCY
# ============================================================

print()
print(
    "========================================"
)

print(
    "SELECTED METHOD FREQUENCY"
)

print(
    "========================================"
)


print(
    fold_summary[
        "Selected_Method"
    ].value_counts()
)


print()


print(
    f"Mean selected threshold: "
    f"{fold_summary['Selected_Threshold'].mean():.3f}"
)

print(
    f"Threshold range: "
    f"{fold_summary['Selected_Threshold'].min():.2f}"
    f" - "
    f"{fold_summary['Selected_Threshold'].max():.2f}"
)


# ============================================================
# 31. MISCLASSIFIED PATIENTS
# ============================================================

misclassified = (
    final_predictions[
        final_predictions[
            "True_ICH"
        ]
        !=
        final_predictions[
            "Prediction"
        ]
    ]
)


print()
print(
    "========================================"
)

print(
    "MISCLASSIFIED PATIENTS"
)

print(
    "========================================"
)


if len(
    misclassified
) == 0:

    print(
        "None"
    )

else:

    print(
        misclassified[
            [
                "Patient_ID",
                "True_ICH",
                "Prediction",
                "Selected_Score",
                "Selected_Method",
                "Selected_Threshold",
                "Outer_Fold",
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# 32. SAVE RESULTS
# ============================================================

final_predictions.to_csv(
    prediction_file,
    index=False,
)


fold_summary.to_csv(
    fold_summary_file,
    index=False,
)


print()
print(
    "========================================"
)

print(
    "FILES SAVED"
)

print(
    "========================================"
)


print(
    prediction_file
)

print()

print(
    fold_summary_file
)