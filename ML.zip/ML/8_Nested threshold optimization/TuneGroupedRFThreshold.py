from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

from sklearn.model_selection import StratifiedGroupKFold

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
)


# ============================================================
# 1. PATHS
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)

input_file = (
    dataset_root
    / "slice_level_ct_features.csv"
)

output_predictions = (
    dataset_root
    / "rf_nested_threshold_predictions.csv"
)

output_folds = (
    dataset_root
    / "rf_nested_threshold_folds.csv"
)


# ============================================================
# 2. LOAD DATA
# ============================================================

df = pd.read_csv(
    input_file
)

print()
print("========================================")
print("DATASET")
print("========================================")

print(f"Slices: {len(df)}")
print(
    f"Patients: "
    f"{df['Patient_ID'].nunique()}"
)

print()


# ============================================================
# 3. FEATURES
# ============================================================

features = [

    "Mean_HU",
    "Median_HU",
    "Std_HU",
    "Min_HU",
    "Max_HU",

    "P10_HU",
    "P25_HU",
    "P75_HU",
    "P90_HU",
    "P95_HU",
    "P99_HU",

    "IQR_HU",

    "Fraction_Above_40HU",
    "Fraction_Above_50HU",
    "Fraction_Above_60HU",
    "Fraction_Above_70HU",
    "Fraction_Above_80HU",

    "HU_Skewness",
    "HU_Kurtosis",
    "HU_Entropy",

    "Top1Percent_Mean_HU",
    "Top5Percent_Mean_HU",

    "Largest_Above50HU_Area_mm2",
    "Largest_Above60HU_Area_mm2",
    "Largest_Above70HU_Area_mm2",
]


# ============================================================
# 4. DATA
# ============================================================

X = df[
    features
].copy()

y = (
    df[
        "Slice_ICH"
    ]
    .astype(int)
)

groups = (
    df[
        "Patient_ID"
    ]
    .astype(int)
)


# ============================================================
# 5. MODEL CREATION
# ============================================================

def create_model():

    return Pipeline(
        steps=[

            (
                "imputer",
                SimpleImputer(
                    strategy="median"
                ),
            ),

            (
                "rf",
                RandomForestClassifier(

                    n_estimators=500,

                    random_state=42,

                    n_jobs=-1,

                    class_weight="balanced_subsample",

                    max_features="sqrt",

                    min_samples_leaf=2,
                ),
            ),
        ]
    )


# ============================================================
# 6. FIND BEST THRESHOLD
# ============================================================

def find_best_threshold(
    true_labels,
    probabilities,
):

    thresholds = np.arange(
        0.05,
        0.81,
        0.01,
    )


    best_threshold = 0.50
    best_balanced_accuracy = -1

    best_sensitivity = 0
    best_specificity = 0


    for threshold in thresholds:

        predictions = (
            probabilities
            >=
            threshold
        ).astype(int)


        cm = confusion_matrix(
            true_labels,
            predictions,
            labels=[0, 1],
        )


        tn, fp, fn, tp = (
            cm.ravel()
        )


        sensitivity = (
            tp
            /
            (tp + fn)
            if (tp + fn) > 0
            else 0
        )


        specificity = (
            tn
            /
            (tn + fp)
            if (tn + fp) > 0
            else 0
        )


        balanced_accuracy = (
            sensitivity
            +
            specificity
        ) / 2


        if (
            balanced_accuracy
            >
            best_balanced_accuracy
        ):

            best_balanced_accuracy = (
                balanced_accuracy
            )

            best_threshold = (
                threshold
            )

            best_sensitivity = (
                sensitivity
            )

            best_specificity = (
                specificity
            )


    return (
        best_threshold,
        best_balanced_accuracy,
        best_sensitivity,
        best_specificity,
    )


# ============================================================
# 7. OUTER CROSS-VALIDATION
# ============================================================

outer_cv = StratifiedGroupKFold(

    n_splits=5,

    shuffle=True,

    random_state=42,
)


# ============================================================
# 8. STORAGE
# ============================================================

oof_probability = np.full(
    len(df),
    np.nan,
)

oof_prediction = np.full(
    len(df),
    -1,
    dtype=int,
)

oof_threshold = np.full(
    len(df),
    np.nan,
)

fold_number = np.full(
    len(df),
    -1,
    dtype=int,
)

fold_results = []


# ============================================================
# 9. OUTER LOOP
# ============================================================

for outer_fold, (
    train_index,
    test_index,
) in enumerate(

    outer_cv.split(
        X,
        y,
        groups=groups,
    ),

    start=1,
):


    print()
    print(
        "========================================"
    )

    print(
        f"OUTER FOLD {outer_fold}"
    )

    print(
        "========================================"
    )


    X_train = X.iloc[
        train_index
    ].reset_index(
        drop=True
    )

    y_train = y.iloc[
        train_index
    ].reset_index(
        drop=True
    )

    group_train = groups.iloc[
        train_index
    ].reset_index(
        drop=True
    )


    X_test = X.iloc[
        test_index
    ]

    y_test = y.iloc[
        test_index
    ]

    group_test = groups.iloc[
        test_index
    ]


    # ========================================================
    # 10. CHECK PATIENT LEAKAGE
    # ========================================================

    overlap = set(
        group_train.unique()
    ).intersection(
        set(
            group_test.unique()
        )
    )


    print(
        f"Training patients: "
        f"{group_train.nunique()}"
    )

    print(
        f"Testing patients: "
        f"{group_test.nunique()}"
    )

    print(
        f"Patient overlap: "
        f"{len(overlap)}"
    )


    if len(overlap) != 0:

        raise RuntimeError(
            "Patient leakage detected."
        )


    # ========================================================
    # 11. INNER CROSS-VALIDATION
    # ========================================================

    inner_cv = StratifiedGroupKFold(

        n_splits=4,

        shuffle=True,

        random_state=(
            100
            +
            outer_fold
        ),
    )


    inner_probability = np.full(
        len(X_train),
        np.nan,
    )


    for inner_train_index, inner_valid_index in (
        inner_cv.split(
            X_train,
            y_train,
            groups=group_train,
        )
    ):


        X_inner_train = (
            X_train.iloc[
                inner_train_index
            ]
        )

        y_inner_train = (
            y_train.iloc[
                inner_train_index
            ]
        )


        X_inner_valid = (
            X_train.iloc[
                inner_valid_index
            ]
        )


        model_inner = create_model()


        model_inner.fit(
            X_inner_train,
            y_inner_train,
        )


        probabilities_inner = (
            model_inner
            .predict_proba(
                X_inner_valid
            )[:, 1]
        )


        inner_probability[
            inner_valid_index
        ] = (
            probabilities_inner
        )


    # ========================================================
    # 12. CHECK INNER PREDICTIONS
    # ========================================================

    if np.any(
        np.isnan(
            inner_probability
        )
    ):

        raise RuntimeError(
            "Some inner-CV slices "
            "did not receive predictions."
        )


    # ========================================================
    # 13. FIND THRESHOLD USING ONLY OUTER TRAINING DATA
    # ========================================================

    (
        best_threshold,
        inner_balanced_accuracy,
        inner_sensitivity,
        inner_specificity,
    ) = find_best_threshold(

        y_train.values,

        inner_probability,
    )


    print()

    print(
        f"Selected threshold: "
        f"{best_threshold:.2f}"
    )

    print(
        f"Inner balanced accuracy: "
        f"{inner_balanced_accuracy:.3f}"
    )

    print(
        f"Inner sensitivity: "
        f"{inner_sensitivity:.3f}"
    )

    print(
        f"Inner specificity: "
        f"{inner_specificity:.3f}"
    )


    # ========================================================
    # 14. TRAIN FINAL OUTER MODEL
    # ========================================================

    final_model = create_model()


    final_model.fit(
        X_train,
        y_train,
    )


    # ========================================================
    # 15. TEST ON UNSEEN OUTER PATIENTS
    # ========================================================

    test_probability = (
        final_model
        .predict_proba(
            X_test
        )[:, 1]
    )


    test_prediction = (
        test_probability
        >=
        best_threshold
    ).astype(int)


    # ========================================================
    # 16. STORE OOF RESULTS
    # ========================================================

    oof_probability[
        test_index
    ] = (
        test_probability
    )


    oof_prediction[
        test_index
    ] = (
        test_prediction
    )


    oof_threshold[
        test_index
    ] = (
        best_threshold
    )


    fold_number[
        test_index
    ] = (
        outer_fold
    )


    # ========================================================
    # 17. OUTER-FOLD METRICS
    # ========================================================

    cm = confusion_matrix(
        y_test,
        test_prediction,
        labels=[0, 1],
    )


    tn, fp, fn, tp = (
        cm.ravel()
    )


    sensitivity = (
        tp
        /
        (tp + fn)
    )


    specificity = (
        tn
        /
        (tn + fp)
    )


    balanced_accuracy = (
        sensitivity
        +
        specificity
    ) / 2


    auc = roc_auc_score(
        y_test,
        test_probability,
    )


    print()

    print(
        f"OUTER sensitivity: "
        f"{sensitivity:.3f}"
    )

    print(
        f"OUTER specificity: "
        f"{specificity:.3f}"
    )

    print(
        f"OUTER balanced accuracy: "
        f"{balanced_accuracy:.3f}"
    )

    print(
        f"OUTER ROC-AUC: "
        f"{auc:.3f}"
    )


    fold_results.append(
        {
            "Fold":
                outer_fold,

            "Threshold":
                best_threshold,

            "Inner_Balanced_Accuracy":
                inner_balanced_accuracy,

            "Inner_Sensitivity":
                inner_sensitivity,

            "Inner_Specificity":
                inner_specificity,

            "Outer_Sensitivity":
                sensitivity,

            "Outer_Specificity":
                specificity,

            "Outer_Balanced_Accuracy":
                balanced_accuracy,

            "Outer_ROC_AUC":
                auc,
        }
    )


# ============================================================
# 18. FINAL OUT-OF-FOLD EVALUATION
# ============================================================

print()
print(
    "========================================"
)

print(
    "FINAL NESTED-CV RESULTS"
)

print(
    "========================================"
)


cm = confusion_matrix(
    y,
    oof_prediction,
    labels=[0, 1],
)


tn, fp, fn, tp = (
    cm.ravel()
)


accuracy = accuracy_score(
    y,
    oof_prediction,
)


balanced_accuracy = (
    balanced_accuracy_score(
        y,
        oof_prediction,
    )
)


sensitivity = recall_score(
    y,
    oof_prediction,
    zero_division=0,
)


specificity = (
    tn
    /
    (tn + fp)
)


precision = precision_score(
    y,
    oof_prediction,
    zero_division=0,
)


f1 = f1_score(
    y,
    oof_prediction,
    zero_division=0,
)


roc_auc = roc_auc_score(
    y,
    oof_probability,
)


average_precision = (
    average_precision_score(
        y,
        oof_probability,
    )
)


print(
    f"Accuracy: "
    f"{accuracy:.3f}"
)

print(
    f"Balanced accuracy: "
    f"{balanced_accuracy:.3f}"
)

print(
    f"Sensitivity: "
    f"{sensitivity:.3f}"
)

print(
    f"Specificity: "
    f"{specificity:.3f}"
)

print(
    f"Precision: "
    f"{precision:.3f}"
)

print(
    f"F1: "
    f"{f1:.3f}"
)

print(
    f"ROC-AUC: "
    f"{roc_auc:.3f}"
)

print(
    f"Average precision: "
    f"{average_precision:.3f}"
)

print()

print(
    "Confusion Matrix:"
)

print(
    cm
)


# ============================================================
# 19. THRESHOLD SUMMARY
# ============================================================

fold_table = pd.DataFrame(
    fold_results
)


print()
print(
    "========================================"
)

print(
    "THRESHOLDS BY FOLD"
)

print(
    "========================================"
)


print(
    fold_table.to_string(
        index=False
    )
)


print()

print(
    f"Mean selected threshold: "
    f"{fold_table['Threshold'].mean():.3f}"
)

print(
    f"Threshold range: "
    f"{fold_table['Threshold'].min():.2f}"
    f" - "
    f"{fold_table['Threshold'].max():.2f}"
)


# ============================================================
# 20. SAVE PREDICTIONS
# ============================================================

prediction_table = pd.DataFrame(
    {
        "Patient_ID":
            df[
                "Patient_ID"
            ].values,

        "Array_Index":
            df[
                "Array_Index"
            ].values,

        "True_Slice_ICH":
            y.values,

        "Probability":
            oof_probability,

        "Threshold":
            oof_threshold,

        "Prediction":
            oof_prediction,

        "Fold":
            fold_number,
    }
)


prediction_table.to_csv(
    output_predictions,
    index=False,
)


fold_table.to_csv(
    output_folds,
    index=False,
)


# ============================================================
# 21. FILES
# ============================================================

print()
print(
    "========================================"
)

print(
    "FILES SAVED"
)

print(
    "========================================"
)

print(
    output_predictions
)

print()

print(
    output_folds
)