from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd

from scipy.ndimage import (
    label,
    binary_fill_holes,
    binary_closing,
    binary_opening,
    binary_erosion,
)


# ============================================================
# 1. DATASET ROOT
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)


# ============================================================
# 2. INPUT PATHS
# ============================================================

ct_folder = dataset_root / "ct_scans"

demographics_file = dataset_root / "Patient_demographics.csv"


# ============================================================
# 3. OUTPUT PATHS
# ============================================================

output_feature_file = (
    dataset_root / "ml_features_ct_only.csv"
)

output_qc_file = (
    dataset_root / "brain_extraction_qc.csv"
)


# ============================================================
# 4. CHECK INPUT FILES
# ============================================================

if not ct_folder.exists():

    raise FileNotFoundError(
        f"CT folder not found:\n{ct_folder}"
    )


if not demographics_file.exists():

    raise FileNotFoundError(
        f"Patient demographics file not found:\n"
        f"{demographics_file}"
    )


# ============================================================
# 5. LOAD ORIGINAL PATIENT DEMOGRAPHICS
# ============================================================

# The original CSV has two header rows.
# We skip those rows and define clean column names ourselves.

column_names = [
    "Patient_ID",
    "Age_years",
    "Gender",
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural",
    "Fracture",
    "Note",
]


patients = pd.read_csv(
    demographics_file,
    skiprows=2,
    header=None,
    names=column_names,
)


# ============================================================
# 6. CLEAN PATIENT ID
# ============================================================

patients["Patient_ID"] = pd.to_numeric(
    patients["Patient_ID"],
    errors="coerce",
)


# Remove summary rows or invalid rows
patients = patients.dropna(
    subset=["Patient_ID"]
).copy()


patients["Patient_ID"] = (
    patients["Patient_ID"]
    .astype(int)
)


# ============================================================
# 7. CLEAN AGE
# ============================================================

patients["Age_years"] = pd.to_numeric(
    patients["Age_years"],
    errors="coerce",
)


# ============================================================
# 8. CLEAN GENDER
# ============================================================

patients["Gender"] = (
    patients["Gender"]
    .astype(str)
    .str.strip()
)


def encode_sex(value):

    value = str(value).strip().lower()

    if value == "male":
        return 0

    if value == "female":
        return 1

    return np.nan


patients["Sex_binary"] = (
    patients["Gender"]
    .apply(encode_sex)
)


# ============================================================
# 9. CLEAN HEMORRHAGE LABELS
# ============================================================

hemorrhage_columns = [
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural",
]


for column in hemorrhage_columns:

    patients[column] = pd.to_numeric(
        patients[column],
        errors="coerce",
    )

    patients[column] = (
        patients[column]
        .fillna(0)
        .astype(int)
    )


# ============================================================
# 10. CREATE OVERALL ICH LABEL
# ============================================================

# ICH = Intracranial Hemorrhage
#
# 1 = at least one hemorrhage subtype exists
# 0 = none of the hemorrhage subtypes exist

patients["ICH"] = (
    patients[hemorrhage_columns]
    .max(axis=1)
    .astype(int)
)


# ============================================================
# 11. CLEAN FRACTURE COLUMN
# ============================================================

patients["Fracture"] = pd.to_numeric(
    patients["Fracture"],
    errors="coerce",
)

patients["Fracture"] = (
    patients["Fracture"]
    .fillna(0)
    .astype(int)
)


# ============================================================
# 12. AGE QUALITY-CONTROL FLAG
# ============================================================

def age_quality_control(age):

    if pd.isna(age):
        return "MISSING"

    if age < 1:
        return "CHECK_INFANT_AGE"

    return "OK"


patients["Age_QC"] = (
    patients["Age_years"]
    .apply(age_quality_control)
)


# ============================================================
# 13. FIND A PATIENT'S NIFTI CT
# ============================================================

def find_ct_file(patient_id):

    possible_files = [
        ct_folder / f"{patient_id:03d}.nii",
        ct_folder / f"{patient_id:03d}.nii.gz",
        ct_folder / f"{patient_id}.nii",
        ct_folder / f"{patient_id}.nii.gz",
    ]

    for file_path in possible_files:

        if file_path.exists():
            return file_path

    return None


# ============================================================
# 14. KEEP LARGEST CONNECTED COMPONENT
# ============================================================

def keep_largest_component(binary_image):

    labeled_image, number_of_components = label(
        binary_image
    )

    if number_of_components == 0:

        return np.zeros_like(
            binary_image,
            dtype=bool,
        )


    component_sizes = np.bincount(
        labeled_image.ravel()
    )

    component_sizes[0] = 0


    largest_label = np.argmax(
        component_sizes
    )


    return (
        labeled_image
        ==
        largest_label
    )


# ============================================================
# 15. KEEP LARGE CONNECTED COMPONENTS
# ============================================================

def keep_large_components(
    binary_image,
    minimum_size=200,
):

    labeled_image, number_of_components = label(
        binary_image
    )

    if number_of_components == 0:

        return np.zeros_like(
            binary_image,
            dtype=bool,
        )


    component_sizes = np.bincount(
        labeled_image.ravel()
    )


    keep_component = (
        component_sizes
        >=
        minimum_size
    )

    keep_component[0] = False


    cleaned_image = (
        keep_component[
            labeled_image
        ]
    )


    return cleaned_image


# ============================================================
# 16. CREATE HEAD MASK
# ============================================================

def create_head_mask(ct_slice):

    # Remove surrounding air
    head_mask = (
        ct_slice > -200
    )


    # Close small gaps
    head_mask = binary_closing(
        head_mask,
        structure=np.ones(
            (5, 5),
            dtype=bool,
        ),
        iterations=2,
    )


    # Keep main connected head
    head_mask = keep_largest_component(
        head_mask
    )


    # Fill the inside of the head
    head_mask = binary_fill_holes(
        head_mask
    )


    return head_mask


# ============================================================
# 17. CREATE CANDIDATE BRAIN MASK FOR ONE SLICE
# ============================================================

def create_brain_mask(ct_slice):

    # --------------------------------------------------------
    # Detect high-density skull
    # --------------------------------------------------------

    bone_mask = (
        ct_slice >= 200
    )


    # --------------------------------------------------------
    # Close small gaps in the skull
    # --------------------------------------------------------

    closed_bone = binary_closing(
        bone_mask,
        structure=np.ones(
            (5, 5),
            dtype=bool,
        ),
        iterations=2,
    )


    # --------------------------------------------------------
    # Fill area enclosed by skull
    # --------------------------------------------------------

    skull_filled = binary_fill_holes(
        closed_bone
    )


    height, width = ct_slice.shape

    center_y = height // 2
    center_x = width // 2


    center_inside = bool(
        skull_filled[
            center_y,
            center_x
        ]
    )


    filled_fraction = (
        np.sum(skull_filled)
        /
        skull_filled.size
    )


    # --------------------------------------------------------
    # If skull enclosure fails, fall back to head geometry
    # --------------------------------------------------------

    if (
        not center_inside
        or
        filled_fraction < 0.03
    ):

        head_mask = create_head_mask(
            ct_slice
        )


        intracranial_mask = binary_erosion(
            head_mask,
            structure=np.ones(
                (3, 3),
                dtype=bool,
            ),
            iterations=10,
        )


    else:

        intracranial_mask = binary_erosion(
            skull_filled,
            structure=np.ones(
                (3, 3),
                dtype=bool,
            ),
            iterations=3,
        )


    # --------------------------------------------------------
    # Keep plausible intracranial soft-tissue HU values
    #
    # This removes:
    # air
    # most skull/bone
    #
    # but retains:
    # brain tissue
    # CSF
    # most acute hemorrhage
    # --------------------------------------------------------

    soft_tissue_mask = (
        (ct_slice >= -20)
        &
        (ct_slice <= 120)
    )


    brain_mask = (
        intracranial_mask
        &
        soft_tissue_mask
    )


    # --------------------------------------------------------
    # Remove tiny noise
    # --------------------------------------------------------

    brain_mask = binary_opening(
        brain_mask,
        structure=np.ones(
            (3, 3),
            dtype=bool,
        ),
        iterations=1,
    )


    brain_mask = binary_closing(
        brain_mask,
        structure=np.ones(
            (3, 3),
            dtype=bool,
        ),
        iterations=1,
    )


    brain_mask = keep_large_components(
        brain_mask,
        minimum_size=200,
    )


    return brain_mask


# ============================================================
# 18. CALCULATE HISTOGRAM ENTROPY
# ============================================================

def calculate_entropy(values):

    if len(values) == 0:
        return np.nan


    histogram, _ = np.histogram(
        values,
        bins=64,
        range=(-20, 120),
    )


    histogram = histogram.astype(float)


    if histogram.sum() == 0:
        return np.nan


    probabilities = (
        histogram
        /
        histogram.sum()
    )


    probabilities = probabilities[
        probabilities > 0
    ]


    entropy = -np.sum(
        probabilities
        *
        np.log2(
            probabilities
        )
    )


    return float(
        entropy
    )


# ============================================================
# 19. FEATURE EXTRACTION RESULTS
# ============================================================

feature_rows = []

qc_rows = []


# ============================================================
# 20. PROCESS EACH PATIENT
# ============================================================

for _, patient in patients.iterrows():

    patient_id = int(
        patient["Patient_ID"]
    )


    ct_path = find_ct_file(
        patient_id
    )


    # Skip patients not included in our CT subset
    if ct_path is None:
        continue


    print("========================================")
    print(f"PATIENT {patient_id}")
    print("========================================")

    print(
        f"CT file: {ct_path.name}"
    )


    # ========================================================
    # 21. LOAD CT VOLUME
    # ========================================================

    ct_image = nib.load(
        str(ct_path)
    )

    ct_data = ct_image.get_fdata()


    voxel_size = (
        ct_image.header
        .get_zooms()[:3]
    )


    print(
        f"CT shape: {ct_data.shape}"
    )

    print(
        f"Voxel size: {voxel_size}"
    )


    # ========================================================
    # 22. BUILD 3D CANDIDATE BRAIN MASK
    # ========================================================

    brain_mask_3d = np.zeros_like(
        ct_data,
        dtype=bool,
    )


    usable_slices = 0


    for slice_index in range(
        ct_data.shape[2]
    ):

        ct_slice = ct_data[
            :,
            :,
            slice_index
        ]


        brain_mask = create_brain_mask(
            ct_slice
        )


        brain_pixels = int(
            np.sum(
                brain_mask
            )
        )


        # Ignore extremely small edge slices
        if brain_pixels < 500:

            continue


        brain_mask_3d[
            :,
            :,
            slice_index
        ] = brain_mask


        usable_slices += 1


    # ========================================================
    # 23. EXTRACT HU VALUES
    # ========================================================

    brain_voxels = int(
        np.sum(
            brain_mask_3d
        )
    )


    if brain_voxels == 0:

        print(
            "WARNING: No brain voxels were extracted."
        )

        print()

        continue


    brain_hu = ct_data[
        brain_mask_3d
    ]


    brain_hu = brain_hu[
        np.isfinite(
            brain_hu
        )
    ]


    # ========================================================
    # 24. BASIC INTENSITY FEATURES
    # ========================================================

    mean_hu = float(
        np.mean(
            brain_hu
        )
    )


    median_hu = float(
        np.median(
            brain_hu
        )
    )


    std_hu = float(
        np.std(
            brain_hu
        )
    )


    minimum_hu = float(
        np.min(
            brain_hu
        )
    )


    maximum_hu = float(
        np.max(
            brain_hu
        )
    )


    # ========================================================
    # 25. PERCENTILE FEATURES
    # ========================================================

    p10 = float(
        np.percentile(
            brain_hu,
            10,
        )
    )


    p25 = float(
        np.percentile(
            brain_hu,
            25,
        )
    )


    p75 = float(
        np.percentile(
            brain_hu,
            75,
        )
    )


    p90 = float(
        np.percentile(
            brain_hu,
            90,
        )
    )


    p95 = float(
        np.percentile(
            brain_hu,
            95,
        )
    )


    iqr = (
        p75 - p25
    )


    # ========================================================
    # 26. HYPERDENSE FRACTIONS
    # ========================================================

    fraction_above_40 = float(
        np.mean(
            brain_hu > 40
        )
    )


    fraction_above_50 = float(
        np.mean(
            brain_hu > 50
        )
    )


    fraction_above_60 = float(
        np.mean(
            brain_hu > 60
        )
    )


    fraction_above_80 = float(
        np.mean(
            brain_hu > 80
        )
    )


    # ========================================================
    # 27. ENTROPY
    # ========================================================

    entropy = calculate_entropy(
        brain_hu
    )


    # ========================================================
    # 28. APPROXIMATE EXTRACTED VOLUME
    # ========================================================

    voxel_volume_mm3 = (
        float(voxel_size[0])
        *
        float(voxel_size[1])
        *
        float(voxel_size[2])
    )


    extracted_volume_ml = (
        brain_voxels
        *
        voxel_volume_mm3
        /
        1000.0
    )


    # ========================================================
    # 29. STORE ML FEATURES + LABELS
    # ========================================================

    feature_rows.append(
        {
            # ------------------------------------------------
            # Identification
            # ------------------------------------------------

            "Patient_ID":
                patient_id,


            # ------------------------------------------------
            # Demographic predictors
            # ------------------------------------------------

            "Age_years":
                patient["Age_years"],

            "Sex_binary":
                patient["Sex_binary"],


            # ------------------------------------------------
            # CT-derived predictors
            # ------------------------------------------------

            "Mean_Brain_HU":
                mean_hu,

            "Median_Brain_HU":
                median_hu,

            "Std_Brain_HU":
                std_hu,

            "Min_Brain_HU":
                minimum_hu,

            "Max_Brain_HU":
                maximum_hu,

            "P10_HU":
                p10,

            "P25_HU":
                p25,

            "P75_HU":
                p75,

            "P90_HU":
                p90,

            "P95_HU":
                p95,

            "IQR_HU":
                iqr,

            "Fraction_Above_40HU":
                fraction_above_40,

            "Fraction_Above_50HU":
                fraction_above_50,

            "Fraction_Above_60HU":
                fraction_above_60,

            "Fraction_Above_80HU":
                fraction_above_80,

            "HU_Entropy":
                entropy,


            # ------------------------------------------------
            # QC / geometry
            #
            # Keep for inspection.
            # Do not use in the first RF yet.
            # ------------------------------------------------

            "Extracted_Volume_mL":
                extracted_volume_ml,

            "Feature_Voxel_Count":
                brain_voxels,

            "Feature_Slice_Count":
                usable_slices,


            # ------------------------------------------------
            # PRIMARY TARGET
            # ------------------------------------------------

            "ICH":
                patient["ICH"],


            # ------------------------------------------------
            # SUBTYPE TARGETS
            # ------------------------------------------------

            "Intraventricular":
                patient[
                    "Intraventricular"
                ],

            "Intraparenchymal":
                patient[
                    "Intraparenchymal"
                ],

            "Subarachnoid":
                patient[
                    "Subarachnoid"
                ],

            "Epidural":
                patient[
                    "Epidural"
                ],

            "Subdural":
                patient[
                    "Subdural"
                ],


            # ------------------------------------------------
            # Other metadata
            # ------------------------------------------------

            "Fracture":
                patient[
                    "Fracture"
                ],

            "Age_QC":
                patient[
                    "Age_QC"
                ],
        }
    )


    # ========================================================
    # 30. STORE QC INFORMATION
    # ========================================================

    qc_rows.append(
        {
            "Patient_ID":
                patient_id,

            "CT_File":
                ct_path.name,

            "CT_Slices":
                ct_data.shape[2],

            "Feature_Slices":
                usable_slices,

            "Feature_Voxels":
                brain_voxels,

            "Extracted_Volume_mL":
                extracted_volume_ml,

            "Mean_HU":
                mean_hu,

            "Median_HU":
                median_hu,

            "P90_HU":
                p90,

            "Fraction_Above_50HU":
                fraction_above_50,
        }
    )


    # ========================================================
    # 31. PRINT PATIENT RESULTS
    # ========================================================

    print(
        f"Usable slices: "
        f"{usable_slices}"
    )

    print(
        f"Extracted voxels: "
        f"{brain_voxels}"
    )

    print(
        f"Mean HU: "
        f"{mean_hu:.2f}"
    )

    print(
        f"Median HU: "
        f"{median_hu:.2f}"
    )

    print(
        f"Std HU: "
        f"{std_hu:.2f}"
    )

    print(
        f"P90 HU: "
        f"{p90:.2f}"
    )

    print(
        f"Fraction > 50 HU: "
        f"{fraction_above_50:.4f}"
    )

    print(
        f"ICH label: "
        f"{int(patient['ICH'])}"
    )

    print()


# ============================================================
# 32. CREATE DATAFRAMES
# ============================================================

feature_table = pd.DataFrame(
    feature_rows
)

qc_table = pd.DataFrame(
    qc_rows
)


# ============================================================
# 33. SAVE FEATURE TABLE
# ============================================================

feature_table.to_csv(
    output_feature_file,
    index=False,
)


# ============================================================
# 34. SAVE QC TABLE
# ============================================================

qc_table.to_csv(
    output_qc_file,
    index=False,
)


# ============================================================
# 35. FINAL DATASET SUMMARY
# ============================================================

print()
print("========================================")
print("FINAL ML FEATURE TABLE")
print("========================================")

print(
    f"Patients included: "
    f"{len(feature_table)}"
)

print()


if len(feature_table) > 0:

    print(
        f"ICH positive: "
        f"{int(feature_table['ICH'].sum())}"
    )

    print(
        f"ICH negative: "
        f"{int((feature_table['ICH'] == 0).sum())}"
    )

    print()


    print("Gender:")

    print(
        feature_table[
            "Sex_binary"
        ].value_counts(
            dropna=False
        )
    )

    print()


# ============================================================
# 36. HEMORRHAGE SUBTYPE COUNTS
# ============================================================

print("========================================")
print("HEMORRHAGE SUBTYPE COUNTS")
print("========================================")


for column in hemorrhage_columns:

    if column in feature_table.columns:

        print(
            f"{column}: "
            f"{int(feature_table[column].sum())}"
        )


# ============================================================
# 37. FEATURE SUMMARY
# ============================================================

print()
print("========================================")
print("CT FEATURE SUMMARY")
print("========================================")


summary_columns = [
    "Mean_Brain_HU",
    "Median_Brain_HU",
    "Std_Brain_HU",
    "P90_HU",
    "P95_HU",
    "Fraction_Above_40HU",
    "Fraction_Above_50HU",
    "Fraction_Above_60HU",
    "HU_Entropy",
]


if len(feature_table) > 0:

    print(
        feature_table[
            summary_columns
        ].describe()
    )


# ============================================================
# 38. SHOW AGE QC CASES
# ============================================================

print()
print("========================================")
print("AGE QC")
print("========================================")


age_qc_cases = feature_table[
    feature_table[
        "Age_QC"
    ] != "OK"
]


if len(age_qc_cases) == 0:

    print(
        "No age QC cases."
    )

else:

    print(
        age_qc_cases[
            [
                "Patient_ID",
                "Age_years",
                "Age_QC",
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# 39. OUTPUT FILES
# ============================================================

print()
print("========================================")
print("FILES SAVED")
print("========================================")

print(
    f"ML feature table:\n"
    f"{output_feature_file}"
)

print()

print(
    f"Brain extraction QC:\n"
    f"{output_qc_file}"
)