from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier

from sklearn.impute import SimpleImputer

from sklearn.pipeline import Pipeline

from sklearn.model_selection import (
    StratifiedGroupKFold,
)

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
)


# ============================================================
# 1. DATASET ROOT
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)


# ============================================================
# 2. INPUT FILE
# ============================================================

input_file = (
    dataset_root
    /
    "slice_level_ct_features.csv"
)


# ============================================================
# 3. OUTPUT FILES
# ============================================================

prediction_file = (
    dataset_root
    /
    "rf_slice_grouped_predictions.csv"
)


importance_file = (
    dataset_root
    /
    "rf_slice_feature_importance.csv"
)


patient_prediction_file = (
    dataset_root
    /
    "rf_patient_predictions_from_slices.csv"
)


# ============================================================
# 4. CHECK INPUT
# ============================================================

if not input_file.exists():

    raise FileNotFoundError(
        f"Could not find:\n{input_file}"
    )


# ============================================================
# 5. LOAD DATA
# ============================================================

df = pd.read_csv(
    input_file
)


print()
print("========================================")
print("DATASET")
print("========================================")

print(
    f"Total slices: {len(df)}"
)

print(
    f"Patients: {df['Patient_ID'].nunique()}"
)

print()


# ============================================================
# 6. TARGET
# ============================================================

y = pd.to_numeric(
    df["Slice_ICH"],
    errors="coerce",
)


valid_rows = y.notna()


df = df[
    valid_rows
].copy()


y = y[
    valid_rows
].astype(int)


# ============================================================
# 7. PATIENT GROUP
# ============================================================

groups = (
    df[
        "Patient_ID"
    ]
    .astype(int)
)


# ============================================================
# 8. CT-ONLY FEATURE LIST
# ============================================================

ct_features = [

    "Mean_HU",

    "Median_HU",

    "Std_HU",

    "Min_HU",

    "Max_HU",

    "P10_HU",

    "P25_HU",

    "P75_HU",

    "P90_HU",

    "P95_HU",

    "P99_HU",

    "IQR_HU",

    "Fraction_Above_40HU",

    "Fraction_Above_50HU",

    "Fraction_Above_60HU",

    "Fraction_Above_70HU",

    "Fraction_Above_80HU",

    "HU_Skewness",

    "HU_Kurtosis",

    "HU_Entropy",

    "Top1Percent_Mean_HU",

    "Top5Percent_Mean_HU",

    "Largest_Above50HU_Area_mm2",

    "Largest_Above60HU_Area_mm2",

    "Largest_Above70HU_Area_mm2",
]


# ============================================================
# 9. CHECK FEATURES
# ============================================================

missing_features = [

    feature

    for feature in ct_features

    if feature not in df.columns
]


if len(missing_features) > 0:

    print(
        "Missing features:"
    )

    for feature in missing_features:

        print(
            feature
        )


    raise ValueError(
        "Required CT features are missing."
    )


# ============================================================
# 10. FEATURE MATRIX
# ============================================================

X = df[
    ct_features
].copy()


# ============================================================
# 11. CLASS DISTRIBUTION
# ============================================================

positive_count = int(
    np.sum(
        y == 1
    )
)


negative_count = int(
    np.sum(
        y == 0
    )
)


print(
    "========================================"
)

print(
    "SLICE CLASS DISTRIBUTION"
)

print(
    "========================================"
)

print(
    f"No hemorrhage slices: "
    f"{negative_count}"
)

print(
    f"Hemorrhage slices: "
    f"{positive_count}"
)

print(
    f"Positive percentage: "
    f"{100 * positive_count / len(y):.2f}%"
)

print()


# ============================================================
# 12. GROUPED CROSS-VALIDATION
# ============================================================

cv = StratifiedGroupKFold(

    n_splits=5,

    shuffle=True,

    random_state=42,
)


# ============================================================
# 13. STORAGE FOR OUT-OF-FOLD RESULTS
# ============================================================

oof_probability = np.full(
    len(df),
    np.nan,
)


oof_prediction = np.full(
    len(df),
    -1,
    dtype=int,
)


fold_number = np.full(
    len(df),
    -1,
    dtype=int,
)


feature_importance_folds = []


# ============================================================
# 14. CROSS-VALIDATION
# ============================================================

for fold, (
    train_index,
    test_index,
) in enumerate(
    cv.split(
        X,
        y,
        groups=groups,
    ),
    start=1,
):


    print()
    print(
        "========================================"
    )

    print(
        f"FOLD {fold}"
    )

    print(
        "========================================"
    )


    X_train = X.iloc[
        train_index
    ]


    X_test = X.iloc[
        test_index
    ]


    y_train = y.iloc[
        train_index
    ]


    y_test = y.iloc[
        test_index
    ]


    train_groups = groups.iloc[
        train_index
    ]


    test_groups = groups.iloc[
        test_index
    ]


    # ========================================================
    # 15. CRITICAL LEAKAGE CHECK
    # ========================================================

    overlap = set(
        train_groups.unique()
    ).intersection(
        set(
            test_groups.unique()
        )
    )


    if len(overlap) > 0:

        raise RuntimeError(
            "PATIENT LEAKAGE DETECTED!"
        )


    print(
        f"Training patients: "
        f"{train_groups.nunique()}"
    )

    print(
        f"Testing patients: "
        f"{test_groups.nunique()}"
    )

    print(
        f"Patient overlap: "
        f"{len(overlap)}"
    )


    print(
        f"Training slices: "
        f"{len(train_index)}"
    )

    print(
        f"Testing slices: "
        f"{len(test_index)}"
    )


    print(
        f"Training positive slices: "
        f"{int(y_train.sum())}"
    )

    print(
        f"Testing positive slices: "
        f"{int(y_test.sum())}"
    )


    # ========================================================
    # 16. MODEL
    # ========================================================

    model = Pipeline(
        steps=[

            (
                "imputer",

                SimpleImputer(
                    strategy="median"
                ),
            ),

            (
                "rf",

                RandomForestClassifier(

                    n_estimators=500,

                    random_state=42,

                    n_jobs=-1,

                    class_weight="balanced_subsample",

                    max_features="sqrt",

                    min_samples_leaf=2,
                ),
            ),
        ]
    )


    # ========================================================
    # 17. TRAIN
    # ========================================================

    model.fit(
        X_train,
        y_train,
    )


    # ========================================================
    # 18. TEST PROBABILITIES
    # ========================================================

    probability = (
        model.predict_proba(
            X_test
        )[
            :,
            1
        ]
    )


    prediction = (
        probability >= 0.5
    ).astype(int)


    # ========================================================
    # 19. STORE OUT-OF-FOLD RESULTS
    # ========================================================

    oof_probability[
        test_index
    ] = probability


    oof_prediction[
        test_index
    ] = prediction


    fold_number[
        test_index
    ] = fold


    # ========================================================
    # 20. FEATURE IMPORTANCE
    # ========================================================

    rf = (
        model
        .named_steps[
            "rf"
        ]
    )


    fold_importance = pd.DataFrame(
        {
            "Feature":
                ct_features,

            "Importance":
                rf.feature_importances_,

            "Fold":
                fold,
        }
    )


    feature_importance_folds.append(
        fold_importance
    )


    # ========================================================
    # 21. FOLD METRICS
    # ========================================================

    fold_balanced_accuracy = (
        balanced_accuracy_score(
            y_test,
            prediction,
        )
    )


    fold_sensitivity = recall_score(
        y_test,
        prediction,
        zero_division=0,
    )


    fold_precision = precision_score(
        y_test,
        prediction,
        zero_division=0,
    )


    fold_f1 = f1_score(
        y_test,
        prediction,
        zero_division=0,
    )


    if len(
        np.unique(
            y_test
        )
    ) == 2:

        fold_auc = roc_auc_score(
            y_test,
            probability,
        )

    else:

        fold_auc = np.nan


    print()

    print(
        f"Balanced accuracy: "
        f"{fold_balanced_accuracy:.3f}"
    )

    print(
        f"Sensitivity: "
        f"{fold_sensitivity:.3f}"
    )

    print(
        f"Precision: "
        f"{fold_precision:.3f}"
    )

    print(
        f"F1: "
        f"{fold_f1:.3f}"
    )

    print(
        f"ROC-AUC: "
        f"{fold_auc:.3f}"
    )


# ============================================================
# 22. CHECK EVERY SLICE RECEIVED OOF PREDICTION
# ============================================================

if np.any(
    np.isnan(
        oof_probability
    )
):

    raise RuntimeError(
        "Some slices did not receive "
        "an out-of-fold prediction."
    )


# ============================================================
# 23. GLOBAL SLICE-LEVEL METRICS
# ============================================================

cm = confusion_matrix(
    y,
    oof_prediction,
    labels=[0, 1],
)


tn, fp, fn, tp = cm.ravel()


accuracy = accuracy_score(
    y,
    oof_prediction,
)


balanced_accuracy = (
    balanced_accuracy_score(
        y,
        oof_prediction,
    )
)


sensitivity = recall_score(
    y,
    oof_prediction,
    zero_division=0,
)


specificity = (
    tn
    /
    (
        tn + fp
    )
)


precision = precision_score(
    y,
    oof_prediction,
    zero_division=0,
)


f1 = f1_score(
    y,
    oof_prediction,
    zero_division=0,
)


roc_auc = roc_auc_score(
    y,
    oof_probability,
)


average_precision = (
    average_precision_score(
        y,
        oof_probability,
    )
)


# ============================================================
# 24. PRINT SLICE-LEVEL RESULTS
# ============================================================

print()
print(
    "========================================"
)

print(
    "OVERALL SLICE-LEVEL RESULTS"
)

print(
    "========================================"
)


print(
    f"Accuracy: "
    f"{accuracy:.3f}"
)

print(
    f"Balanced accuracy: "
    f"{balanced_accuracy:.3f}"
)

print(
    f"Sensitivity: "
    f"{sensitivity:.3f}"
)

print(
    f"Specificity: "
    f"{specificity:.3f}"
)

print(
    f"Precision: "
    f"{precision:.3f}"
)

print(
    f"F1 score: "
    f"{f1:.3f}"
)

print(
    f"ROC-AUC: "
    f"{roc_auc:.3f}"
)

print(
    f"Average precision: "
    f"{average_precision:.3f}"
)


print()

print(
    "Confusion Matrix:"
)

print(
    cm
)


# ============================================================
# 25. SAVE SLICE PREDICTIONS
# ============================================================

prediction_table = pd.DataFrame(
    {
        "Patient_ID":
            df[
                "Patient_ID"
            ].values,

        "Array_Index":
            df[
                "Array_Index"
            ].values,

        "Dataset_Slice_Number":
            df[
                "Dataset_Slice_Number"
            ].values,

        "True_Slice_ICH":
            y.values,

        "Predicted_Probability":
            oof_probability,

        "Predicted_Slice_ICH":
            oof_prediction,

        "Fold":
            fold_number,
    }
)


prediction_table.to_csv(
    prediction_file,
    index=False,
)


# ============================================================
# 26. PATIENT-LEVEL AGGREGATION
# ============================================================

patient_rows = []


for patient_id, patient_data in (
    prediction_table
    .groupby(
        "Patient_ID"
    )
):


    probabilities = (
        patient_data[
            "Predicted_Probability"
        ]
        .values
    )


    true_slice_labels = (
        patient_data[
            "True_Slice_ICH"
        ]
        .values
    )


    # Patient is positive if any
    # included slice is positive.
    true_patient_ich = int(
        np.max(
            true_slice_labels
        )
    )


    maximum_probability = float(
        np.max(
            probabilities
        )
    )


    sorted_probabilities = np.sort(
        probabilities
    )[
        ::-1
    ]


    number_top = min(
        3,
        len(
            sorted_probabilities
        ),
    )


    top3_mean_probability = float(
        np.mean(
            sorted_probabilities[
                :number_top
            ]
        )
    )


    # Initial fixed threshold.
    # We are NOT optimizing the threshold yet.
    max_prediction = int(
        maximum_probability >= 0.5
    )


    top3_prediction = int(
        top3_mean_probability >= 0.5
    )


    patient_rows.append(
        {
            "Patient_ID":
                patient_id,

            "True_Patient_ICH":
                true_patient_ich,

            "Maximum_Slice_Probability":
                maximum_probability,

            "Top3_Mean_Probability":
                top3_mean_probability,

            "Max_Method_Prediction":
                max_prediction,

            "Top3_Method_Prediction":
                top3_prediction,

            "Number_of_Slices":
                len(
                    patient_data
                ),
        }
    )


patient_predictions = pd.DataFrame(
    patient_rows
)


# ============================================================
# 27. PATIENT-LEVEL METRIC FUNCTION
# ============================================================

def evaluate_patient_method(
    table,
    prediction_column,
    probability_column,
    method_name,
):


    true_values = (
        table[
            "True_Patient_ICH"
        ].astype(int)
    )


    predictions = (
        table[
            prediction_column
        ].astype(int)
    )


    probabilities = (
        table[
            probability_column
        ].astype(float)
    )


    cm_patient = confusion_matrix(
        true_values,
        predictions,
        labels=[0, 1],
    )


    tn_p, fp_p, fn_p, tp_p = (
        cm_patient.ravel()
    )


    accuracy_p = accuracy_score(
        true_values,
        predictions,
    )


    balanced_accuracy_p = (
        balanced_accuracy_score(
            true_values,
            predictions,
        )
    )


    sensitivity_p = recall_score(
        true_values,
        predictions,
        zero_division=0,
    )


    specificity_p = (
        tn_p
        /
        (
            tn_p + fp_p
        )
    )


    precision_p = precision_score(
        true_values,
        predictions,
        zero_division=0,
    )


    f1_p = f1_score(
        true_values,
        predictions,
        zero_division=0,
    )


    auc_p = roc_auc_score(
        true_values,
        probabilities,
    )


    ap_p = average_precision_score(
        true_values,
        probabilities,
    )


    print()
    print(
        "----------------------------------------"
    )

    print(
        method_name
    )

    print(
        "----------------------------------------"
    )


    print(
        f"Accuracy: "
        f"{accuracy_p:.3f}"
    )

    print(
        f"Balanced accuracy: "
        f"{balanced_accuracy_p:.3f}"
    )

    print(
        f"Sensitivity: "
        f"{sensitivity_p:.3f}"
    )

    print(
        f"Specificity: "
        f"{specificity_p:.3f}"
    )

    print(
        f"Precision: "
        f"{precision_p:.3f}"
    )

    print(
        f"F1: "
        f"{f1_p:.3f}"
    )

    print(
        f"ROC-AUC: "
        f"{auc_p:.3f}"
    )

    print(
        f"Average precision: "
        f"{ap_p:.3f}"
    )


    print()

    print(
        "Confusion Matrix:"
    )

    print(
        cm_patient
    )


# ============================================================
# 28. PATIENT-LEVEL RESULTS
# ============================================================

print()
print(
    "========================================"
)

print(
    "PATIENT-LEVEL RESULTS FROM SLICE MODEL"
)

print(
    "========================================"
)


evaluate_patient_method(

    patient_predictions,

    "Max_Method_Prediction",

    "Maximum_Slice_Probability",

    "MAXIMUM SLICE PROBABILITY",
)


evaluate_patient_method(

    patient_predictions,

    "Top3_Method_Prediction",

    "Top3_Mean_Probability",

    "TOP-3 SLICE MEAN PROBABILITY",
)


# ============================================================
# 29. SAVE PATIENT PREDICTIONS
# ============================================================

patient_predictions.to_csv(
    patient_prediction_file,
    index=False,
)


# ============================================================
# 30. AVERAGE FEATURE IMPORTANCE ACROSS FOLDS
# ============================================================

all_importance = pd.concat(
    feature_importance_folds,
    ignore_index=True,
)


importance_summary = (
    all_importance
    .groupby(
        "Feature"
    )[
        "Importance"
    ]
    .agg(
        [
            "mean",
            "std",
        ]
    )
    .reset_index()
)


importance_summary = (
    importance_summary
    .sort_values(
        "mean",
        ascending=False,
    )
)


importance_summary.columns = [
    "Feature",
    "Mean_Importance",
    "Std_Importance",
]


importance_summary.to_csv(
    importance_file,
    index=False,
)


# ============================================================
# 31. PRINT FEATURE IMPORTANCE
# ============================================================

print()
print(
    "========================================"
)

print(
    "FEATURE IMPORTANCE"
)

print(
    "========================================"
)


print(
    importance_summary.to_string(
        index=False
    )
)


# ============================================================
# 32. OUTPUT FILES
# ============================================================

print()
print(
    "========================================"
)

print(
    "FILES SAVED"
)

print(
    "========================================"
)


print(
    prediction_file
)

print()

print(
    patient_prediction_file
)

print()

print(
    importance_file
)