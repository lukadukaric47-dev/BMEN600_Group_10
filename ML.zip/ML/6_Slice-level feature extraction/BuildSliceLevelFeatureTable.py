from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd

from scipy.ndimage import (
    label,
    binary_fill_holes,
    binary_closing,
    binary_opening,
    binary_erosion,
)

from scipy.stats import (
    skew,
    kurtosis,
)


# ============================================================
# 1. DATASET ROOT
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)


# ============================================================
# 2. INPUT FILES
# ============================================================

ct_folder = dataset_root / "ct_scans"

demographics_file = (
    dataset_root / "Patient_demographics.csv"
)

diagnosis_file = (
    dataset_root / "hemorrhage_diagnosis_raw_ct.csv"
)


# ============================================================
# 3. OUTPUT FILES
# ============================================================

output_file = (
    dataset_root / "slice_level_ct_features.csv"
)

qc_output_file = (
    dataset_root / "slice_level_feature_qc.csv"
)


# ============================================================
# 4. CHECK INPUT FILES
# ============================================================

for path in [
    ct_folder,
    demographics_file,
    diagnosis_file,
]:

    if not path.exists():

        raise FileNotFoundError(
            f"Could not find:\n{path}"
        )


# ============================================================
# 5. LOAD PATIENT DEMOGRAPHICS
# ============================================================

demographic_columns = [
    "Patient_ID",
    "Age_years",
    "Gender",
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural",
    "Fracture",
    "Note",
]


patients = pd.read_csv(
    demographics_file,
    skiprows=2,
    header=None,
    names=demographic_columns,
)


patients["Patient_ID"] = pd.to_numeric(
    patients["Patient_ID"],
    errors="coerce",
)


patients = patients.dropna(
    subset=["Patient_ID"]
).copy()


patients["Patient_ID"] = (
    patients["Patient_ID"]
    .astype(int)
)


patients["Age_years"] = pd.to_numeric(
    patients["Age_years"],
    errors="coerce",
)


def encode_sex(value):

    value = str(value).strip().lower()

    if value == "male":
        return 0

    if value == "female":
        return 1

    return np.nan


patients["Sex_binary"] = (
    patients["Gender"]
    .apply(encode_sex)
)


# ============================================================
# 6. CLEAN PATIENT HEMORRHAGE LABELS
# ============================================================

hemorrhage_columns = [
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural",
]


for column in hemorrhage_columns:

    patients[column] = pd.to_numeric(
        patients[column],
        errors="coerce",
    )

    patients[column] = (
        patients[column]
        .fillna(0)
        .astype(int)
    )


patients["Patient_ICH"] = (
    patients[hemorrhage_columns]
    .max(axis=1)
    .astype(int)
)


# ============================================================
# 7. LOAD SLICE-LEVEL RADIOLOGIST LABELS
# ============================================================

diagnosis = pd.read_csv(
    diagnosis_file
)


required_diagnosis_columns = [
    "PatientNumber",
    "SliceNumber",
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural",
    "No_Hemorrhage",
]


for column in required_diagnosis_columns:

    if column not in diagnosis.columns:

        raise ValueError(
            f"Missing diagnosis column: {column}"
        )


# ============================================================
# 8. CLEAN DIAGNOSIS TABLE
# ============================================================

diagnosis["PatientNumber"] = pd.to_numeric(
    diagnosis["PatientNumber"],
    errors="coerce",
)


diagnosis["SliceNumber"] = pd.to_numeric(
    diagnosis["SliceNumber"],
    errors="coerce",
)


diagnosis = diagnosis.dropna(
    subset=[
        "PatientNumber",
        "SliceNumber",
    ]
).copy()


diagnosis["PatientNumber"] = (
    diagnosis["PatientNumber"]
    .astype(int)
)


slice_label_columns = [
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural",
    "No_Hemorrhage",
]


for column in slice_label_columns:

    diagnosis[column] = pd.to_numeric(
        diagnosis[column],
        errors="coerce",
    )

    diagnosis[column] = (
        diagnosis[column]
        .fillna(0)
        .astype(int)
    )


# ============================================================
# 9. CREATE BINARY SLICE ICH LABEL
# ============================================================

diagnosis["Slice_ICH"] = (
    diagnosis[
        [
            "Intraventricular",
            "Intraparenchymal",
            "Subarachnoid",
            "Epidural",
            "Subdural",
        ]
    ]
    .max(axis=1)
    .astype(int)
)


# ============================================================
# 10. CHECK No_Hemorrhage CONSISTENCY
# ============================================================

diagnosis[
    "Expected_No_Hemorrhage"
] = (
    1 - diagnosis["Slice_ICH"]
)


diagnosis[
    "No_Hemorrhage_Mismatch"
] = (
    diagnosis[
        "Expected_No_Hemorrhage"
    ]
    !=
    diagnosis[
        "No_Hemorrhage"
    ]
)


label_mismatches = int(
    diagnosis[
        "No_Hemorrhage_Mismatch"
    ].sum()
)


print()
print("========================================")
print("SLICE LABEL CHECK")
print("========================================")

print(
    f"No_Hemorrhage inconsistencies: "
    f"{label_mismatches}"
)

print()


# ============================================================
# 11. FIND CT FILE
# ============================================================

def find_ct_file(patient_id):

    possible_files = [
        ct_folder / f"{patient_id:03d}.nii",
        ct_folder / f"{patient_id:03d}.nii.gz",
        ct_folder / f"{patient_id}.nii",
        ct_folder / f"{patient_id}.nii.gz",
    ]

    for file_path in possible_files:

        if file_path.exists():
            return file_path

    return None


# ============================================================
# 12. KEEP LARGEST COMPONENT
# ============================================================

def keep_largest_component(binary_image):

    labeled_image, number_components = label(
        binary_image
    )

    if number_components == 0:

        return np.zeros_like(
            binary_image,
            dtype=bool,
        )


    sizes = np.bincount(
        labeled_image.ravel()
    )

    sizes[0] = 0


    largest_label = np.argmax(
        sizes
    )


    return (
        labeled_image
        ==
        largest_label
    )


# ============================================================
# 13. KEEP LARGE COMPONENTS
# ============================================================

def keep_large_components(
    binary_image,
    minimum_size=200,
):

    labeled_image, number_components = label(
        binary_image
    )

    if number_components == 0:

        return np.zeros_like(
            binary_image,
            dtype=bool,
        )


    sizes = np.bincount(
        labeled_image.ravel()
    )


    valid_components = (
        sizes >= minimum_size
    )


    valid_components[0] = False


    return valid_components[
        labeled_image
    ]


# ============================================================
# 14. CREATE HEAD MASK
# ============================================================

def create_head_mask(ct_slice):

    # Remove surrounding air
    head_mask = (
        ct_slice > -200
    )


    head_mask = binary_closing(
        head_mask,
        structure=np.ones(
            (5, 5),
            dtype=bool,
        ),
        iterations=2,
    )


    head_mask = keep_largest_component(
        head_mask
    )


    head_mask = binary_fill_holes(
        head_mask
    )


    return head_mask


# ============================================================
# 15. CREATE BRAIN / INTRACRANIAL SOFT-TISSUE MASK
# ============================================================

def create_brain_mask(ct_slice):

    # --------------------------------------------------------
    # Detect skull
    # --------------------------------------------------------

    bone_mask = (
        ct_slice >= 200
    )


    closed_bone = binary_closing(
        bone_mask,
        structure=np.ones(
            (5, 5),
            dtype=bool,
        ),
        iterations=2,
    )


    skull_filled = binary_fill_holes(
        closed_bone
    )


    height, width = ct_slice.shape

    center_y = height // 2
    center_x = width // 2


    center_inside = bool(
        skull_filled[
            center_y,
            center_x
        ]
    )


    filled_fraction = (
        np.sum(skull_filled)
        /
        skull_filled.size
    )


    # --------------------------------------------------------
    # Fallback if skull enclosure is incomplete
    # --------------------------------------------------------

    if (
        not center_inside
        or
        filled_fraction < 0.03
    ):

        head_mask = create_head_mask(
            ct_slice
        )


        intracranial_mask = binary_erosion(
            head_mask,
            structure=np.ones(
                (3, 3),
                dtype=bool,
            ),
            iterations=10,
        )


    else:

        intracranial_mask = binary_erosion(
            skull_filled,
            structure=np.ones(
                (3, 3),
                dtype=bool,
            ),
            iterations=3,
        )


    # --------------------------------------------------------
    # HU range appropriate for intracranial soft tissue
    # --------------------------------------------------------

    soft_tissue_mask = (
        (ct_slice >= -20)
        &
        (ct_slice <= 120)
    )


    brain_mask = (
        intracranial_mask
        &
        soft_tissue_mask
    )


    brain_mask = binary_opening(
        brain_mask,
        structure=np.ones(
            (3, 3),
            dtype=bool,
        ),
        iterations=1,
    )


    brain_mask = binary_closing(
        brain_mask,
        structure=np.ones(
            (3, 3),
            dtype=bool,
        ),
        iterations=1,
    )


    brain_mask = keep_large_components(
        brain_mask,
        minimum_size=200,
    )


    return brain_mask


# ============================================================
# 16. ENTROPY
# ============================================================

def calculate_entropy(values):

    if len(values) == 0:
        return np.nan


    histogram, _ = np.histogram(
        values,
        bins=64,
        range=(-20, 120),
    )


    histogram = histogram.astype(
        float
    )


    if histogram.sum() == 0:
        return np.nan


    probability = (
        histogram
        /
        histogram.sum()
    )


    probability = probability[
        probability > 0
    ]


    return float(
        -np.sum(
            probability
            *
            np.log2(
                probability
            )
        )
    )


# ============================================================
# 17. TOP PERCENT MEAN
# ============================================================

def top_percent_mean(
    values,
    percent,
):

    if len(values) == 0:
        return np.nan


    number_to_keep = max(
        1,
        int(
            np.ceil(
                len(values)
                *
                percent
            )
        ),
    )


    highest_values = np.partition(
        values,
        -number_to_keep,
    )[
        -number_to_keep:
    ]


    return float(
        np.mean(
            highest_values
        )
    )


# ============================================================
# 18. LARGEST HIGH-DENSITY COMPONENT
# ============================================================

def largest_high_density_component(
    ct_slice,
    brain_mask,
    threshold,
):

    high_density_mask = (
        brain_mask
        &
        (
            ct_slice
            >
            threshold
        )
    )


    labeled_image, number_components = label(
        high_density_mask
    )


    if number_components == 0:

        return 0


    sizes = np.bincount(
        labeled_image.ravel()
    )


    if len(sizes) <= 1:
        return 0


    return int(
        np.max(
            sizes[1:]
        )
    )


# ============================================================
# 19. FEATURE AND QC TABLES
# ============================================================

feature_rows = []

qc_rows = []


# ============================================================
# 20. DEMOGRAPHIC QC FOR THE 50 CT PATIENTS
# ============================================================

available_patients = []


for _, patient in patients.iterrows():

    patient_id = int(
        patient["Patient_ID"]
    )


    if find_ct_file(
        patient_id
    ) is not None:

        available_patients.append(
            patient_id
        )


patient_subset = patients[
    patients[
        "Patient_ID"
    ].isin(
        available_patients
    )
].copy()


print("========================================")
print("DEMOGRAPHIC QC")
print("========================================")

print(
    f"Patients with CT files: "
    f"{len(patient_subset)}"
)

print()


print("Sex x ICH:")

print(
    pd.crosstab(
        patient_subset[
            "Gender"
        ],
        patient_subset[
            "Patient_ICH"
        ],
        margins=True,
    )
)

print()


print("Age by ICH:")

print(
    patient_subset.groupby(
        "Patient_ICH"
    )[
        "Age_years"
    ].agg(
        [
            "count",
            "mean",
            "median",
            "std",
            "min",
            "max",
        ]
    )
)

print()


# ============================================================
# 21. PROCESS EACH PATIENT
# ============================================================

for _, patient in patient_subset.iterrows():

    patient_id = int(
        patient["Patient_ID"]
    )


    ct_path = find_ct_file(
        patient_id
    )


    print(
        f"Processing patient {patient_id}..."
    )


    # ========================================================
    # LOAD CT
    # ========================================================

    ct_image = nib.load(
        str(ct_path)
    )


    ct_data = ct_image.get_fdata()


    voxel_size = (
        ct_image.header
        .get_zooms()[:3]
    )


    pixel_area_mm2 = (
        float(
            voxel_size[0]
        )
        *
        float(
            voxel_size[1]
        )
    )


    number_ct_slices = (
        ct_data.shape[2]
    )


    # ========================================================
    # FIND PATIENT'S SLICE LABELS
    # ========================================================

    patient_labels = diagnosis[
        diagnosis[
            "PatientNumber"
        ]
        ==
        patient_id
    ].copy()


    patient_labels = (
        patient_labels
        .sort_values(
            "SliceNumber"
        )
        .reset_index(
            drop=True
        )
    )


    number_label_rows = len(
        patient_labels
    )


    # ========================================================
    # STRICT CT/LABEL COUNT CHECK
    # ========================================================

    if (
        number_ct_slices
        !=
        number_label_rows
    ):

        print(
            "  WARNING: slice count mismatch"
        )

        print(
            f"  CT slices: {number_ct_slices}"
        )

        print(
            f"  Label rows: {number_label_rows}"
        )


        qc_rows.append(
            {
                "Patient_ID":
                    patient_id,

                "CT_File":
                    ct_path.name,

                "CT_Slices":
                    number_ct_slices,

                "Label_Rows":
                    number_label_rows,

                "Status":
                    "PATIENT_SLICE_COUNT_MISMATCH",
            }
        )


        continue


    # ========================================================
    # 22. PROCESS EVERY SLICE
    # ========================================================

    for array_index in range(
        number_ct_slices
    ):

        ct_slice = ct_data[
            :,
            :,
            array_index
        ]


        label_row = patient_labels.iloc[
            array_index
        ]


        dataset_slice_number = int(
            label_row[
                "SliceNumber"
            ]
        )


        slice_ich = int(
            label_row[
                "Slice_ICH"
            ]
        )


        # ====================================================
        # CREATE BRAIN MASK
        # ====================================================

        brain_mask = create_brain_mask(
            ct_slice
        )


        brain_voxel_count = int(
            np.sum(
                brain_mask
            )
        )


        # ====================================================
        # SKIP EXTREME EDGE SLICES
        # ====================================================

        if brain_voxel_count < 500:

            qc_rows.append(
                {
                    "Patient_ID":
                        patient_id,

                    "CT_File":
                        ct_path.name,

                    "Array_Index":
                        array_index,

                    "Dataset_Slice_Number":
                        dataset_slice_number,

                    "Slice_ICH":
                        slice_ich,

                    "Brain_Voxels":
                        brain_voxel_count,

                    "Status":
                        "SKIPPED_SMALL_BRAIN_REGION",
                }
            )


            continue


        # ====================================================
        # EXTRACT CT HU VALUES
        # ====================================================

        brain_hu = ct_slice[
            brain_mask
        ]


        brain_hu = brain_hu[
            np.isfinite(
                brain_hu
            )
        ]


        if len(brain_hu) == 0:

            continue


        # ====================================================
        # BASIC HU FEATURES
        # ====================================================

        mean_hu = float(
            np.mean(
                brain_hu
            )
        )


        median_hu = float(
            np.median(
                brain_hu
            )
        )


        std_hu = float(
            np.std(
                brain_hu
            )
        )


        min_hu = float(
            np.min(
                brain_hu
            )
        )


        max_hu = float(
            np.max(
                brain_hu
            )
        )


        # ====================================================
        # PERCENTILES
        # ====================================================

        p10 = float(
            np.percentile(
                brain_hu,
                10,
            )
        )


        p25 = float(
            np.percentile(
                brain_hu,
                25,
            )
        )


        p75 = float(
            np.percentile(
                brain_hu,
                75,
            )
        )


        p90 = float(
            np.percentile(
                brain_hu,
                90,
            )
        )


        p95 = float(
            np.percentile(
                brain_hu,
                95,
            )
        )


        p99 = float(
            np.percentile(
                brain_hu,
                99,
            )
        )


        iqr = (
            p75 - p25
        )


        # ====================================================
        # HIGH-DENSITY FRACTIONS
        # ====================================================

        fraction_40 = float(
            np.mean(
                brain_hu > 40
            )
        )


        fraction_50 = float(
            np.mean(
                brain_hu > 50
            )
        )


        fraction_60 = float(
            np.mean(
                brain_hu > 60
            )
        )


        fraction_70 = float(
            np.mean(
                brain_hu > 70
            )
        )


        fraction_80 = float(
            np.mean(
                brain_hu > 80
            )
        )


        # ====================================================
        # DISTRIBUTION SHAPE
        # ====================================================

        hu_skewness = float(
            skew(
                brain_hu
            )
        )


        hu_kurtosis = float(
            kurtosis(
                brain_hu
            )
        )


        entropy = calculate_entropy(
            brain_hu
        )


        # ====================================================
        # UPPER-TAIL FEATURES
        # ====================================================

        top_1_percent_mean = (
            top_percent_mean(
                brain_hu,
                0.01,
            )
        )


        top_5_percent_mean = (
            top_percent_mean(
                brain_hu,
                0.05,
            )
        )


        # ====================================================
        # LOCAL HIGH-DENSITY REGION FEATURES
        # ====================================================

        largest_50_pixels = (
            largest_high_density_component(
                ct_slice,
                brain_mask,
                50,
            )
        )


        largest_60_pixels = (
            largest_high_density_component(
                ct_slice,
                brain_mask,
                60,
            )
        )


        largest_70_pixels = (
            largest_high_density_component(
                ct_slice,
                brain_mask,
                70,
            )
        )


        largest_50_area_mm2 = (
            largest_50_pixels
            *
            pixel_area_mm2
        )


        largest_60_area_mm2 = (
            largest_60_pixels
            *
            pixel_area_mm2
        )


        largest_70_area_mm2 = (
            largest_70_pixels
            *
            pixel_area_mm2
        )


        # ====================================================
        # STORE SLICE
        # ====================================================

        feature_rows.append(
            {
                # --------------------------------------------
                # Identification
                # --------------------------------------------

                "Patient_ID":
                    patient_id,

                "Array_Index":
                    array_index,

                "Dataset_Slice_Number":
                    dataset_slice_number,


                # --------------------------------------------
                # Demographics
                # --------------------------------------------

                "Age_years":
                    patient[
                        "Age_years"
                    ],

                "Sex_binary":
                    patient[
                        "Sex_binary"
                    ],


                # --------------------------------------------
                # CT-only features
                # --------------------------------------------

                "Mean_HU":
                    mean_hu,

                "Median_HU":
                    median_hu,

                "Std_HU":
                    std_hu,

                "Min_HU":
                    min_hu,

                "Max_HU":
                    max_hu,

                "P10_HU":
                    p10,

                "P25_HU":
                    p25,

                "P75_HU":
                    p75,

                "P90_HU":
                    p90,

                "P95_HU":
                    p95,

                "P99_HU":
                    p99,

                "IQR_HU":
                    iqr,

                "Fraction_Above_40HU":
                    fraction_40,

                "Fraction_Above_50HU":
                    fraction_50,

                "Fraction_Above_60HU":
                    fraction_60,

                "Fraction_Above_70HU":
                    fraction_70,

                "Fraction_Above_80HU":
                    fraction_80,

                "HU_Skewness":
                    hu_skewness,

                "HU_Kurtosis":
                    hu_kurtosis,

                "HU_Entropy":
                    entropy,

                "Top1Percent_Mean_HU":
                    top_1_percent_mean,

                "Top5Percent_Mean_HU":
                    top_5_percent_mean,

                "Largest_Above50HU_Area_mm2":
                    largest_50_area_mm2,

                "Largest_Above60HU_Area_mm2":
                    largest_60_area_mm2,

                "Largest_Above70HU_Area_mm2":
                    largest_70_area_mm2,


                # --------------------------------------------
                # QC only
                # --------------------------------------------

                "Brain_Voxel_Count":
                    brain_voxel_count,


                # --------------------------------------------
                # GROUND-TRUTH TARGETS
                # --------------------------------------------

                "Slice_ICH":
                    slice_ich,

                "No_Hemorrhage":
                    int(
                        label_row[
                            "No_Hemorrhage"
                        ]
                    ),

                "Intraventricular":
                    int(
                        label_row[
                            "Intraventricular"
                        ]
                    ),

                "Intraparenchymal":
                    int(
                        label_row[
                            "Intraparenchymal"
                        ]
                    ),

                "Subarachnoid":
                    int(
                        label_row[
                            "Subarachnoid"
                        ]
                    ),

                "Epidural":
                    int(
                        label_row[
                            "Epidural"
                        ]
                    ),

                "Subdural":
                    int(
                        label_row[
                            "Subdural"
                        ]
                    ),

                "Patient_ICH":
                    int(
                        patient[
                            "Patient_ICH"
                        ]
                    ),
            }
        )


        qc_rows.append(
            {
                "Patient_ID":
                    patient_id,

                "CT_File":
                    ct_path.name,

                "Array_Index":
                    array_index,

                "Dataset_Slice_Number":
                    dataset_slice_number,

                "Slice_ICH":
                    slice_ich,

                "Brain_Voxels":
                    brain_voxel_count,

                "Status":
                    "OK",
            }
        )


# ============================================================
# 23. BUILD OUTPUT TABLES
# ============================================================

slice_features = pd.DataFrame(
    feature_rows
)


qc_table = pd.DataFrame(
    qc_rows
)


# ============================================================
# 24. SAVE FILES
# ============================================================

slice_features.to_csv(
    output_file,
    index=False,
)


qc_table.to_csv(
    qc_output_file,
    index=False,
)


# ============================================================
# 25. FINAL SUMMARY
# ============================================================

print()
print("========================================")
print("SLICE-LEVEL FEATURE TABLE")
print("========================================")

print(
    f"Total usable slices: "
    f"{len(slice_features)}"
)


if len(slice_features) > 0:

    positive_slices = int(
        slice_features[
            "Slice_ICH"
        ].sum()
    )


    negative_slices = int(
        (
            slice_features[
                "Slice_ICH"
            ]
            ==
            0
        ).sum()
    )


    print(
        f"Hemorrhage-positive slices: "
        f"{positive_slices}"
    )


    print(
        f"No-hemorrhage slices: "
        f"{negative_slices}"
    )


    print(
        f"Patients represented: "
        f"{slice_features['Patient_ID'].nunique()}"
    )


# ============================================================
# 26. SKIPPED SLICE SUMMARY
# ============================================================

print()
print("========================================")
print("SKIPPED SLICE QC")
print("========================================")


if len(qc_table) > 0:

    skipped = qc_table[
        qc_table[
            "Status"
        ]
        ==
        "SKIPPED_SMALL_BRAIN_REGION"
    ]


    print(
        f"Skipped edge slices: "
        f"{len(skipped)}"
    )


    if len(skipped) > 0:

        skipped_positive = int(
            skipped[
                "Slice_ICH"
            ].fillna(0).sum()
        )


        print(
            f"Skipped hemorrhage-positive slices: "
            f"{skipped_positive}"
        )


# ============================================================
# 27. SLICE SUBTYPE COUNTS
# ============================================================

print()
print("========================================")
print("POSITIVE SLICE COUNTS BY SUBTYPE")
print("========================================")


for column in hemorrhage_columns:

    if column in slice_features.columns:

        print(
            f"{column}: "
            f"{int(slice_features[column].sum())}"
        )


# ============================================================
# 28. PATIENT COUNTS BY SUBTYPE
# ============================================================

print()
print("========================================")
print("POSITIVE PATIENT COUNTS BY SUBTYPE")
print("========================================")


patient_level_labels = (
    slice_features
    .groupby(
        "Patient_ID"
    )[
        hemorrhage_columns
    ]
    .max()
)


for column in hemorrhage_columns:

    print(
        f"{column}: "
        f"{int(patient_level_labels[column].sum())}"
    )


# ============================================================
# 29. CT FEATURE COMPARISON
# ============================================================

print()
print("========================================")
print("SELECTED FEATURES BY SLICE LABEL")
print("========================================")


selected_features = [
    "Mean_HU",
    "Std_HU",
    "P90_HU",
    "P95_HU",
    "P99_HU",
    "Fraction_Above_50HU",
    "Fraction_Above_60HU",
    "Fraction_Above_80HU",
    "Top1Percent_Mean_HU",
    "Largest_Above60HU_Area_mm2",
]


if len(slice_features) > 0:

    comparison = (
        slice_features
        .groupby(
            "Slice_ICH"
        )[
            selected_features
        ]
        .mean()
        .T
    )


    comparison.columns = [
        "No_Hemorrhage_Mean",
        "Hemorrhage_Mean",
    ]


    comparison[
        "Difference"
    ] = (
        comparison[
            "Hemorrhage_Mean"
        ]
        -
        comparison[
            "No_Hemorrhage_Mean"
        ]
    )


    print(
        comparison.to_string()
    )


# ============================================================
# 30. OUTPUT FILES
# ============================================================

print()
print("========================================")
print("FILES SAVED")
print("========================================")

print(
    f"Slice feature table:\n"
    f"{output_file}"
)

print()

print(
    f"QC table:\n"
    f"{qc_output_file}"
)