from pathlib import Path

import nibabel as nib
import numpy as np
import matplotlib.pyplot as plt

from scipy.ndimage import (
    label,
    binary_fill_holes,
    binary_closing,
    binary_opening,
    binary_erosion
)


# ============================================================
# 1. DATASET PATH
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)

ct_folder = dataset_root / "ct_scans"


# ============================================================
# 2. SELECT PATIENT
# ============================================================

patient_id = 71


# ============================================================
# 3. SELECT SLICE
# ============================================================

# Patient 71 previously showed the largest hemorrhage on slice 17.
# We will inspect that slice first.

selected_slice = 17


# ============================================================
# 4. FIND CT FILE
# ============================================================

possible_ct_files = [
    ct_folder / f"{patient_id:03d}.nii",
    ct_folder / f"{patient_id:03d}.nii.gz",
    ct_folder / f"{patient_id}.nii",
    ct_folder / f"{patient_id}.nii.gz",
]

ct_path = None

for file_path in possible_ct_files:

    if file_path.exists():

        ct_path = file_path
        break


if ct_path is None:

    raise FileNotFoundError(
        f"Could not find CT file for patient {patient_id}"
    )


# ============================================================
# 5. LOAD CT
# ============================================================

ct_image = nib.load(
    str(ct_path)
)

ct_data = ct_image.get_fdata()


print("========================================")
print("CT INFORMATION")
print("========================================")

print(f"Patient ID: {patient_id}")
print(f"CT file: {ct_path.name}")
print(f"Shape: {ct_data.shape}")
print(f"Voxel size: {ct_image.header.get_zooms()}")
print()


# ============================================================
# 6. CHECK SLICE NUMBER
# ============================================================

if selected_slice < 0 or selected_slice >= ct_data.shape[2]:

    raise ValueError(
        f"Slice {selected_slice} does not exist. "
        f"This CT contains {ct_data.shape[2]} slices."
    )


# ============================================================
# 7. EXTRACT AXIAL SLICE
# ============================================================

ct_slice = ct_data[
    :,
    :,
    selected_slice
]


# ============================================================
# 8. HELPER FUNCTION:
#    KEEP LARGE CONNECTED REGIONS
# ============================================================

def keep_large_components(binary_image, minimum_size=200):

    labeled_image, number_of_components = label(
        binary_image
    )

    if number_of_components == 0:

        return np.zeros_like(
            binary_image,
            dtype=bool
        )


    component_sizes = np.bincount(
        labeled_image.ravel()
    )


    keep_component = (
        component_sizes >= minimum_size
    )


    # Background should never be kept
    keep_component[0] = False


    cleaned_image = keep_component[
        labeled_image
    ]


    return cleaned_image


# ============================================================
# 9. CREATE SKULL / BONE MASK
# ============================================================

# Bone has a very high HU value.
# 200 HU is used here as an initial skull threshold.

bone_mask = (
    ct_slice >= 200
)


# ============================================================
# 10. CLOSE SMALL GAPS IN THE SKULL
# ============================================================

structure = np.ones(
    (5, 5),
    dtype=bool
)

closed_bone = binary_closing(
    bone_mask,
    structure=structure,
    iterations=2
)


# ============================================================
# 11. FILL THE AREA ENCLOSED BY THE SKULL
# ============================================================

skull_filled = binary_fill_holes(
    closed_bone
)


# ============================================================
# 12. CHECK WHETHER SKULL FILL WORKED
# ============================================================

height, width = ct_slice.shape

center_y = height // 2
center_x = width // 2


center_is_inside = bool(
    skull_filled[
        center_y,
        center_x
    ]
)


filled_fraction = (
    np.sum(skull_filled)
    /
    skull_filled.size
)


print("========================================")
print("SKULL FILL CHECK")
print("========================================")

print(
    f"Image center inside filled skull: "
    f"{center_is_inside}"
)

print(
    f"Filled fraction of image: "
    f"{filled_fraction:.3f}"
)

print()


# ============================================================
# 13. FALLBACK METHOD IF SKULL FILL FAILS
# ============================================================

if (
    not center_is_inside
    or
    filled_fraction < 0.03
):

    print(
        "Skull enclosure was incomplete."
    )

    print(
        "Using head-mask fallback method."
    )

    print()


    # --------------------------------------------------------
    # Remove air/background
    # --------------------------------------------------------

    head_mask = (
        ct_slice > -200
    )


    # --------------------------------------------------------
    # Keep large connected structures
    # --------------------------------------------------------

    head_mask = keep_large_components(
        head_mask,
        minimum_size=1000
    )


    # --------------------------------------------------------
    # Fill internal holes
    # --------------------------------------------------------

    head_mask = binary_fill_holes(
        head_mask
    )


    # --------------------------------------------------------
    # Erode inward to move away from skin and skull
    # --------------------------------------------------------

    intracranial_mask = binary_erosion(
        head_mask,
        structure=np.ones(
            (3, 3),
            dtype=bool
        ),
        iterations=10
    )


else:

    print(
        "Skull enclosure looks usable."
    )

    print()


    # --------------------------------------------------------
    # Move a few pixels inward from the skull
    # --------------------------------------------------------

    intracranial_mask = binary_erosion(
        skull_filled,
        structure=np.ones(
            (3, 3),
            dtype=bool
        ),
        iterations=3
    )


# ============================================================
# 14. SELECT PLAUSIBLE BRAIN-TISSUE HU RANGE
# ============================================================

# This range excludes:
# - air
# - most bone
#
# while retaining:
# - brain tissue
# - CSF
# - acute hemorrhage

brain_intensity_mask = (
    (ct_slice >= -20)
    &
    (ct_slice <= 120)
)


# ============================================================
# 15. COMBINE INTRACRANIAL REGION + HU RANGE
# ============================================================

brain_mask = (
    intracranial_mask
    &
    brain_intensity_mask
)


# ============================================================
# 16. CLEAN SMALL NOISY REGIONS
# ============================================================

brain_mask = binary_opening(
    brain_mask,
    structure=np.ones(
        (3, 3),
        dtype=bool
    ),
    iterations=1
)


brain_mask = binary_closing(
    brain_mask,
    structure=np.ones(
        (3, 3),
        dtype=bool
    ),
    iterations=1
)


brain_mask = keep_large_components(
    brain_mask,
    minimum_size=200
)


# ============================================================
# 17. BASIC MASK STATISTICS
# ============================================================

brain_pixels = int(
    np.sum(brain_mask)
)


print("========================================")
print("BRAIN MASK INFORMATION")
print("========================================")

print(
    f"Brain-mask pixels on slice: "
    f"{brain_pixels}"
)

print()


# ============================================================
# 18. CALCULATE PRELIMINARY MEAN HU
# ============================================================

if brain_pixels > 0:

    brain_hu_values = ct_slice[
        brain_mask
    ]


    mean_brain_hu = float(
        np.mean(
            brain_hu_values
        )
    )


    median_brain_hu = float(
        np.median(
            brain_hu_values
        )
    )


    print(
        f"Preliminary mean brain HU: "
        f"{mean_brain_hu:.2f}"
    )

    print(
        f"Preliminary median brain HU: "
        f"{median_brain_hu:.2f}"
    )

else:

    print(
        "WARNING: Brain mask is empty."
    )


print()


# ============================================================
# 19. BRAIN WINDOW FOR DISPLAY
# ============================================================

window_center = 40
window_width = 80

lower_limit = (
    window_center
    -
    window_width / 2
)

upper_limit = (
    window_center
    +
    window_width / 2
)


windowed_ct = np.clip(
    ct_slice,
    lower_limit,
    upper_limit
)


# ============================================================
# 20. CREATE MASKED BRAIN IMAGE
# ============================================================

masked_brain = np.full_like(
    ct_slice,
    np.nan,
    dtype=float
)

masked_brain[
    brain_mask
] = ct_slice[
    brain_mask
]


# ============================================================
# 21. DISPLAY RESULTS
# ============================================================

plt.figure(
    figsize=(16, 4)
)


# ------------------------------------------------------------
# ORIGINAL CT
# ------------------------------------------------------------

plt.subplot(
    1,
    4,
    1
)

plt.imshow(
    np.rot90(
        windowed_ct
    ),
    cmap="gray",
    vmin=lower_limit,
    vmax=upper_limit
)

plt.title(
    f"Original CT\n"
    f"Patient {patient_id}, Slice {selected_slice}"
)

plt.axis(
    "off"
)


# ------------------------------------------------------------
# BRAIN MASK
# ------------------------------------------------------------

plt.subplot(
    1,
    4,
    2
)

plt.imshow(
    np.rot90(
        brain_mask
    ),
    cmap="gray"
)

plt.title(
    "Candidate Brain Mask"
)

plt.axis(
    "off"
)


# ------------------------------------------------------------
# CT + BRAIN MASK OVERLAY
# ------------------------------------------------------------

plt.subplot(
    1,
    4,
    3
)

plt.imshow(
    np.rot90(
        windowed_ct
    ),
    cmap="gray",
    vmin=lower_limit,
    vmax=upper_limit
)

plt.imshow(
    np.rot90(
        brain_mask
    ),
    cmap="Greens",
    alpha=0.35
)

plt.title(
    "CT + Brain Mask"
)

plt.axis(
    "off"
)


# ------------------------------------------------------------
# MASKED BRAIN ONLY
# ------------------------------------------------------------

plt.subplot(
    1,
    4,
    4
)

plt.imshow(
    np.rot90(
        masked_brain
    ),
    cmap="gray",
    vmin=lower_limit,
    vmax=upper_limit
)

plt.title(
    "Brain Region Only"
)

plt.axis(
    "off"
)


plt.tight_layout()

plt.show()