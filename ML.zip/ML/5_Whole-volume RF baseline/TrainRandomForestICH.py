from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier

from sklearn.impute import SimpleImputer

from sklearn.pipeline import Pipeline

from sklearn.model_selection import (
    StratifiedKFold,
    cross_val_predict,
)

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
)


# ============================================================
# 1. DATASET PATH
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)


# ============================================================
# 2. INPUT FEATURE TABLE
# ============================================================

feature_file = (
    dataset_root / "ml_features_ct_only.csv"
)


# ============================================================
# 3. OUTPUT FILES
# ============================================================

comparison_file = (
    dataset_root / "rf_ich_model_comparison.csv"
)

predictions_file = (
    dataset_root / "rf_ich_predictions.csv"
)

importance_file = (
    dataset_root / "rf_ich_feature_importance.csv"
)


# ============================================================
# 4. CHECK INPUT FILE
# ============================================================

if not feature_file.exists():

    raise FileNotFoundError(
        f"Feature table not found:\n{feature_file}"
    )


# ============================================================
# 5. LOAD DATA
# ============================================================

df = pd.read_csv(
    feature_file
)


print("========================================")
print("DATASET")
print("========================================")

print(
    f"Patients: {len(df)}"
)

print()


# ============================================================
# 6. TARGET
# ============================================================

target_column = "ICH"


if target_column not in df.columns:

    raise ValueError(
        "ICH target column was not found."
    )


y = pd.to_numeric(
    df[target_column],
    errors="coerce"
)


# ============================================================
# 7. REMOVE ROWS WITH MISSING TARGET
# ============================================================

valid_target = y.notna()

df = df[
    valid_target
].copy()

y = y[
    valid_target
].astype(int)


# ============================================================
# 8. CHECK CLASS DISTRIBUTION
# ============================================================

class_counts = (
    y.value_counts()
    .sort_index()
)


print("========================================")
print("ICH CLASS DISTRIBUTION")
print("========================================")

print(
    class_counts
)

print()


if len(class_counts) != 2:

    raise ValueError(
        "The ICH target must contain both "
        "0 and 1 classes."
    )


negative_count = int(
    class_counts.get(
        0,
        0
    )
)

positive_count = int(
    class_counts.get(
        1,
        0
    )
)


print(
    f"No hemorrhage: "
    f"{negative_count}"
)

print(
    f"Hemorrhage: "
    f"{positive_count}"
)

print()


# ============================================================
# 9. DETERMINE NUMBER OF CV FOLDS
# ============================================================

minority_count = min(
    negative_count,
    positive_count
)


if minority_count < 2:

    raise ValueError(
        "There are not enough patients in the "
        "minority class for cross-validation."
    )


n_splits = min(
    5,
    minority_count
)


print(
    f"Using {n_splits}-fold "
    f"Stratified Cross-Validation"
)

print()


# ============================================================
# 10. FEATURE GROUPS
# ============================================================

demographic_features = [
    "Age_years",
    "Sex_binary",
]


ct_features = [
    "Mean_Brain_HU",
    "Median_Brain_HU",
    "Std_Brain_HU",

    "P10_HU",
    "P25_HU",
    "P75_HU",
    "P90_HU",
    "P95_HU",

    "IQR_HU",

    "Fraction_Above_40HU",
    "Fraction_Above_50HU",
    "Fraction_Above_60HU",
    "Fraction_Above_80HU",

    "HU_Entropy",
]


combined_features = (
    demographic_features
    +
    ct_features
)


# ============================================================
# 11. CHECK REQUIRED FEATURES
# ============================================================

all_required_features = list(
    dict.fromkeys(
        combined_features
    )
)


missing_features = [
    feature
    for feature in all_required_features
    if feature not in df.columns
]


if len(missing_features) > 0:

    print(
        "Missing feature columns:"
    )

    for feature in missing_features:
        print(feature)

    raise ValueError(
        "Required feature columns are missing."
    )


# ============================================================
# 12. DEFINE MODEL SETS
# ============================================================

model_definitions = {

    "Demographics_Only":
        demographic_features,

    "CT_Only":
        ct_features,

    "Combined":
        combined_features,
}


# ============================================================
# 13. CROSS-VALIDATION SETUP
# ============================================================

cv = StratifiedKFold(
    n_splits=n_splits,
    shuffle=True,
    random_state=42,
)


# ============================================================
# 14. RANDOM FOREST PIPELINE
# ============================================================

def create_model():

    pipeline = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(
                    strategy="median"
                ),
            ),

            (
                "rf",
                RandomForestClassifier(
                    n_estimators=500,

                    random_state=42,

                    class_weight="balanced",

                    n_jobs=-1,

                    max_features="sqrt",
                ),
            ),
        ]
    )

    return pipeline


# ============================================================
# 15. STORE RESULTS
# ============================================================

comparison_results = []

prediction_table = pd.DataFrame(
    {
        "Patient_ID":
            df["Patient_ID"].values,

        "True_ICH":
            y.values,
    }
)


# ============================================================
# 16. TRAIN / VALIDATE EACH MODEL
# ============================================================

for model_name, feature_list in model_definitions.items():

    print("========================================")
    print(model_name)
    print("========================================")


    X = df[
        feature_list
    ].copy()


    model = create_model()


    # ========================================================
    # 17. OUT-OF-FOLD PREDICTED PROBABILITIES
    # ========================================================

    probabilities = cross_val_predict(
        model,
        X,
        y,
        cv=cv,
        method="predict_proba",
        n_jobs=-1,
    )[:, 1]


    # ========================================================
    # 18. CONVERT PROBABILITY TO CLASS
    # ========================================================

    predictions = (
        probabilities >= 0.5
    ).astype(int)


    # ========================================================
    # 19. CONFUSION MATRIX
    # ========================================================

    cm = confusion_matrix(
        y,
        predictions,
        labels=[0, 1],
    )


    tn, fp, fn, tp = (
        cm.ravel()
    )


    # ========================================================
    # 20. METRICS
    # ========================================================

    accuracy = accuracy_score(
        y,
        predictions,
    )


    balanced_accuracy = (
        balanced_accuracy_score(
            y,
            predictions,
        )
    )


    sensitivity = recall_score(
        y,
        predictions,
        pos_label=1,
        zero_division=0,
    )


    if (
        tn + fp
    ) > 0:

        specificity = (
            tn
            /
            (
                tn + fp
            )
        )

    else:

        specificity = np.nan


    precision = precision_score(
        y,
        predictions,
        zero_division=0,
    )


    f1 = f1_score(
        y,
        predictions,
        zero_division=0,
    )


    roc_auc = roc_auc_score(
        y,
        probabilities,
    )


    average_precision = (
        average_precision_score(
            y,
            probabilities,
        )
    )


    # ========================================================
    # 21. PRINT RESULTS
    # ========================================================

    print(
        f"Accuracy: "
        f"{accuracy:.3f}"
    )

    print(
        f"Balanced accuracy: "
        f"{balanced_accuracy:.3f}"
    )

    print(
        f"Sensitivity: "
        f"{sensitivity:.3f}"
    )

    print(
        f"Specificity: "
        f"{specificity:.3f}"
    )

    print(
        f"Precision: "
        f"{precision:.3f}"
    )

    print(
        f"F1 score: "
        f"{f1:.3f}"
    )

    print(
        f"ROC-AUC: "
        f"{roc_auc:.3f}"
    )

    print(
        f"Average precision: "
        f"{average_precision:.3f}"
    )

    print()


    print("Confusion Matrix:")

    print(
        cm
    )

    print()


    # ========================================================
    # 22. SAVE MODEL COMPARISON RESULT
    # ========================================================

    comparison_results.append(
        {
            "Model":
                model_name,

            "Number_of_Features":
                len(feature_list),

            "Accuracy":
                accuracy,

            "Balanced_Accuracy":
                balanced_accuracy,

            "Sensitivity":
                sensitivity,

            "Specificity":
                specificity,

            "Precision":
                precision,

            "F1":
                f1,

            "ROC_AUC":
                roc_auc,

            "Average_Precision":
                average_precision,

            "True_Negative":
                tn,

            "False_Positive":
                fp,

            "False_Negative":
                fn,

            "True_Positive":
                tp,
        }
    )


    # ========================================================
    # 23. SAVE PATIENT-LEVEL PREDICTIONS
    # ========================================================

    prediction_table[
        f"{model_name}_Probability"
    ] = probabilities


    prediction_table[
        f"{model_name}_Prediction"
    ] = predictions


# ============================================================
# 24. CREATE COMPARISON TABLE
# ============================================================

comparison_df = pd.DataFrame(
    comparison_results
)


comparison_df = (
    comparison_df
    .sort_values(
        "ROC_AUC",
        ascending=False,
    )
)


# ============================================================
# 25. SAVE COMPARISON TABLE
# ============================================================

comparison_df.to_csv(
    comparison_file,
    index=False,
)


# ============================================================
# 26. SAVE OUT-OF-FOLD PREDICTIONS
# ============================================================

prediction_table.to_csv(
    predictions_file,
    index=False,
)


# ============================================================
# 27. TRAIN FINAL COMBINED MODEL
#     FOR FEATURE IMPORTANCE ONLY
# ============================================================

X_combined = df[
    combined_features
].copy()


final_model = create_model()


final_model.fit(
    X_combined,
    y,
)


# ============================================================
# 28. GET RANDOM FOREST FEATURE IMPORTANCE
# ============================================================

rf_model = (
    final_model
    .named_steps[
        "rf"
    ]
)


feature_importances = (
    rf_model
    .feature_importances_
)


importance_df = pd.DataFrame(
    {
        "Feature":
            combined_features,

        "Importance":
            feature_importances,
    }
)


importance_df = (
    importance_df
    .sort_values(
        "Importance",
        ascending=False,
    )
)


# ============================================================
# 29. SAVE FEATURE IMPORTANCE
# ============================================================

importance_df.to_csv(
    importance_file,
    index=False,
)


# ============================================================
# 30. PRINT FINAL MODEL COMPARISON
# ============================================================

print()
print("========================================")
print("MODEL COMPARISON")
print("========================================")

print(
    comparison_df[
        [
            "Model",
            "Accuracy",
            "Balanced_Accuracy",
            "Sensitivity",
            "Specificity",
            "F1",
            "ROC_AUC",
            "Average_Precision",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# 31. PRINT FEATURE IMPORTANCE
# ============================================================

print()
print("========================================")
print("COMBINED MODEL FEATURE IMPORTANCE")
print("========================================")

print(
    importance_df.to_string(
        index=False
    )
)


# ============================================================
# 32. OUTPUT FILES
# ============================================================

print()
print("========================================")
print("FILES SAVED")
print("========================================")

print(
    comparison_file
)

print()

print(
    predictions_file
)

print()

print(
    importance_file
)