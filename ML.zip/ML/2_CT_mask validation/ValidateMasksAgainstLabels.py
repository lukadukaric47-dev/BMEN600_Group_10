from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd


# ============================================================
# 1. DATASET ROOT
# ============================================================

dataset_root = Path(
    r"C:\Users\milad\OneDrive - University of Calgary\Courses\Fall 2026\BMEN-600-Biomedical-Engineering-Foundation\files-20261006T174136Z-1-001\files\ct-ich\1.3.1"
)


# ============================================================
# 2. INPUT FILES
# ============================================================

patient_table_file = (
    dataset_root / "patient_table_with_features.csv"
)

diagnosis_file = (
    dataset_root / "hemorrhage_diagnosis_raw_ct.csv"
)

mask_folder = (
    dataset_root / "masks"
)


# ============================================================
# 3. OUTPUT FILES
# ============================================================

output_slice_file = (
    dataset_root / "mask_label_validation_slices.csv"
)

output_patient_file = (
    dataset_root / "mask_label_validation_patients.csv"
)


# ============================================================
# 4. CHECK FILES
# ============================================================

if not patient_table_file.exists():
    raise FileNotFoundError(
        f"Patient table not found:\n{patient_table_file}"
    )

if not diagnosis_file.exists():
    raise FileNotFoundError(
        f"Diagnosis file not found:\n{diagnosis_file}"
    )

if not mask_folder.exists():
    raise FileNotFoundError(
        f"Mask folder not found:\n{mask_folder}"
    )


# ============================================================
# 5. LOAD DATA
# ============================================================

patients = pd.read_csv(
    patient_table_file
)

diagnosis = pd.read_csv(
    diagnosis_file
)


# ============================================================
# 6. PRINT BASIC INFORMATION
# ============================================================

print("========================================")
print("INPUT DATA")
print("========================================")

print(
    f"Patients in patient table: "
    f"{len(patients)}"
)

print(
    f"Rows in diagnosis file: "
    f"{len(diagnosis)}"
)

print()


# ============================================================
# 7. CLEAN PATIENT NUMBER
# ============================================================

diagnosis["PatientNumber"] = pd.to_numeric(
    diagnosis["PatientNumber"],
    errors="coerce"
)

diagnosis["SliceNumber"] = pd.to_numeric(
    diagnosis["SliceNumber"],
    errors="coerce"
)


diagnosis = diagnosis.dropna(
    subset=[
        "PatientNumber",
        "SliceNumber"
    ]
).copy()


diagnosis["PatientNumber"] = (
    diagnosis["PatientNumber"]
    .astype(int)
)

diagnosis["SliceNumber"] = (
    diagnosis["SliceNumber"]
    .astype(int)
)


# ============================================================
# 8. HEMORRHAGE TYPE COLUMNS
# ============================================================

hemorrhage_columns = [
    "Intraventricular",
    "Intraparenchymal",
    "Subarachnoid",
    "Epidural",
    "Subdural"
]


for column in hemorrhage_columns:

    diagnosis[column] = pd.to_numeric(
        diagnosis[column],
        errors="coerce"
    ).fillna(0).astype(int)


# ============================================================
# 9. CREATE BINARY RADIOLOGIST LABEL
# ============================================================

diagnosis["Radiologist_Hemorrhage"] = (
    diagnosis[hemorrhage_columns]
    .max(axis=1)
    .astype(int)
)


# ============================================================
# 10. CLEAN NO_HEMORRHAGE COLUMN
# ============================================================

diagnosis["No_Hemorrhage"] = pd.to_numeric(
    diagnosis["No_Hemorrhage"],
    errors="coerce"
).fillna(0).astype(int)


# ============================================================
# 11. FUNCTION TO FIND MASK FILE
# ============================================================

def find_mask_file(patient_id):

    possible_files = [
        mask_folder / f"{patient_id:03d}.nii",
        mask_folder / f"{patient_id:03d}.nii.gz",
        mask_folder / f"{patient_id}.nii",
        mask_folder / f"{patient_id}.nii.gz"
    ]

    for file_path in possible_files:

        if file_path.exists():
            return file_path

    return None


# ============================================================
# 12. STORE SLICE RESULTS
# ============================================================

slice_results = []


# ============================================================
# 13. PROCESS EACH PATIENT
# ============================================================

for _, patient_row in patients.iterrows():

    patient_id = int(
        patient_row["Patient_ID"]
    )


    print("========================================")
    print(f"PATIENT {patient_id}")
    print("========================================")


    mask_path = find_mask_file(
        patient_id
    )


    if mask_path is None:

        print("Mask: NOT FOUND")
        print()

        continue


    print(
        f"Mask: {mask_path.name}"
    )


    # ========================================================
    # 14. LOAD MASK
    # ========================================================

    mask_image = nib.load(
        str(mask_path)
    )

    mask_data = mask_image.get_fdata()

    binary_mask = (
        mask_data > 0
    )


    number_of_mask_slices = (
        binary_mask.shape[2]
    )


    # ========================================================
    # 15. GET CSV ROWS FOR THIS PATIENT
    # ========================================================

    patient_diagnosis = diagnosis[
        diagnosis["PatientNumber"]
        ==
        patient_id
    ].copy()


    patient_diagnosis = (
        patient_diagnosis
        .sort_values("SliceNumber")
        .reset_index(drop=True)
    )


    print(
        f"Mask slices: "
        f"{number_of_mask_slices}"
    )

    print(
        f"Diagnosis rows: "
        f"{len(patient_diagnosis)}"
    )


    # ========================================================
    # 16. CHECK NUMBER OF SLICES
    # ========================================================

    if len(patient_diagnosis) != number_of_mask_slices:

        print(
            "WARNING: Number of diagnosis rows "
            "does not match mask slices."
        )


    # ========================================================
    # 17. DETERMINE HOW MANY SLICES CAN BE COMPARED
    # ========================================================

    comparable_slices = min(
        number_of_mask_slices,
        len(patient_diagnosis)
    )


    # ========================================================
    # 18. COMPARE EACH SLICE
    # ========================================================

    for array_index in range(
        comparable_slices
    ):

        # ----------------------------------------------------
        # Mask label
        # ----------------------------------------------------

        mask_slice = (
            binary_mask[
                :,
                :,
                array_index
            ]
        )


        mask_positive_pixels = int(
            np.sum(mask_slice)
        )


        mask_has_hemorrhage = int(
            mask_positive_pixels > 0
        )


        # ----------------------------------------------------
        # CSV row
        # ----------------------------------------------------

        diagnosis_row = (
            patient_diagnosis
            .iloc[array_index]
        )


        csv_slice_number = int(
            diagnosis_row[
                "SliceNumber"
            ]
        )


        radiologist_has_hemorrhage = int(
            diagnosis_row[
                "Radiologist_Hemorrhage"
            ]
        )


        # ----------------------------------------------------
        # Agreement
        # ----------------------------------------------------

        agreement = int(
            mask_has_hemorrhage
            ==
            radiologist_has_hemorrhage
        )


        # ----------------------------------------------------
        # Store result
        # ----------------------------------------------------

        slice_results.append(
            {
                "Patient_ID":
                    patient_id,

                "NIFTI_Array_Index":
                    array_index,

                "CSV_Slice_Number":
                    csv_slice_number,

                "Mask_Positive_Voxels":
                    mask_positive_pixels,

                "Mask_Hemorrhage":
                    mask_has_hemorrhage,

                "Radiologist_Hemorrhage":
                    radiologist_has_hemorrhage,

                "Agreement":
                    agreement,

                "Intraventricular":
                    int(
                        diagnosis_row[
                            "Intraventricular"
                        ]
                    ),

                "Intraparenchymal":
                    int(
                        diagnosis_row[
                            "Intraparenchymal"
                        ]
                    ),

                "Subarachnoid":
                    int(
                        diagnosis_row[
                            "Subarachnoid"
                        ]
                    ),

                "Epidural":
                    int(
                        diagnosis_row[
                            "Epidural"
                        ]
                    ),

                "Subdural":
                    int(
                        diagnosis_row[
                            "Subdural"
                        ]
                    )
            }
        )


    print()


# ============================================================
# 19. CREATE SLICE VALIDATION TABLE
# ============================================================

slice_validation = pd.DataFrame(
    slice_results
)


# ============================================================
# 20. SAVE SLICE TABLE
# ============================================================

slice_validation.to_csv(
    output_slice_file,
    index=False
)


# ============================================================
# 21. CALCULATE OVERALL AGREEMENT
# ============================================================

if len(slice_validation) == 0:

    raise RuntimeError(
        "No slices were available for validation."
    )


overall_agreement = (
    slice_validation["Agreement"]
    .mean()
)


# ============================================================
# 22. CONFUSION MATRIX VALUES
# ============================================================

true_positive = int(
    (
        (
            slice_validation[
                "Radiologist_Hemorrhage"
            ] == 1
        )
        &
        (
            slice_validation[
                "Mask_Hemorrhage"
            ] == 1
        )
    ).sum()
)


true_negative = int(
    (
        (
            slice_validation[
                "Radiologist_Hemorrhage"
            ] == 0
        )
        &
        (
            slice_validation[
                "Mask_Hemorrhage"
            ] == 0
        )
    ).sum()
)


false_positive = int(
    (
        (
            slice_validation[
                "Radiologist_Hemorrhage"
            ] == 0
        )
        &
        (
            slice_validation[
                "Mask_Hemorrhage"
            ] == 1
        )
    ).sum()
)


false_negative = int(
    (
        (
            slice_validation[
                "Radiologist_Hemorrhage"
            ] == 1
        )
        &
        (
            slice_validation[
                "Mask_Hemorrhage"
            ] == 0
        )
    ).sum()
)


# ============================================================
# 23. SENSITIVITY
# ============================================================

if (
    true_positive
    +
    false_negative
) > 0:

    sensitivity = (
        true_positive
        /
        (
            true_positive
            +
            false_negative
        )
    )

else:

    sensitivity = np.nan


# ============================================================
# 24. SPECIFICITY
# ============================================================

if (
    true_negative
    +
    false_positive
) > 0:

    specificity = (
        true_negative
        /
        (
            true_negative
            +
            false_positive
        )
    )

else:

    specificity = np.nan


# ============================================================
# 25. PATIENT-LEVEL SUMMARY
# ============================================================

patient_validation = (
    slice_validation
    .groupby("Patient_ID")
    .agg(
        Total_Slices=(
            "Agreement",
            "count"
        ),

        Matching_Slices=(
            "Agreement",
            "sum"
        ),

        Mask_Positive_Slices=(
            "Mask_Hemorrhage",
            "sum"
        ),

        Radiologist_Positive_Slices=(
            "Radiologist_Hemorrhage",
            "sum"
        )
    )
    .reset_index()
)


patient_validation[
    "Agreement_Percent"
] = (
    patient_validation[
        "Matching_Slices"
    ]
    /
    patient_validation[
        "Total_Slices"
    ]
    *
    100
)


# ============================================================
# 26. SAVE PATIENT SUMMARY
# ============================================================

patient_validation.to_csv(
    output_patient_file,
    index=False
)


# ============================================================
# 27. PRINT FINAL SUMMARY
# ============================================================

print()
print("========================================")
print("VALIDATION SUMMARY")
print("========================================")

print(
    f"Total slices compared: "
    f"{len(slice_validation)}"
)

print()

print(
    f"True Positive:  "
    f"{true_positive}"
)

print(
    f"True Negative:  "
    f"{true_negative}"
)

print(
    f"False Positive: "
    f"{false_positive}"
)

print(
    f"False Negative: "
    f"{false_negative}"
)

print()

print(
    f"Overall agreement: "
    f"{overall_agreement * 100:.2f}%"
)

print(
    f"Sensitivity: "
    f"{sensitivity * 100:.2f}%"
)

print(
    f"Specificity: "
    f"{specificity * 100:.2f}%"
)

print()


# ============================================================
# 28. SHOW WORST-MATCHING PATIENTS
# ============================================================

print("========================================")
print("LOWEST PATIENT AGREEMENT")
print("========================================")

print(
    patient_validation
    .sort_values(
        "Agreement_Percent"
    )
    .head(10)
    .to_string(
        index=False
    )
)


# ============================================================
# 29. OUTPUT FILES
# ============================================================

print()
print("========================================")
print("FILES SAVED")
print("========================================")

print(
    output_slice_file
)

print()

print(
    output_patient_file
)